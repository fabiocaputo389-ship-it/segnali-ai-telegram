#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SUPER SCANNER — legge il mercato reale e genera segnali con motore quantitativo + verifica AI (Claude).

Solo libreria standard di Python 3.8+: nessuna dipendenza da installare (va bene anche su Termux).

AVVIO RAPIDO
    python app.py                 # dati reali, dashboard su http://127.0.0.1:8000
    python app.py --demo          # dati simulati (prova offline, tempo accelerato)
    python app.py --netcheck      # controlla quali fonti dati sono raggiungibili
    python app.py --backtest      # misura il tasso di successo storico del motore sui dati reali
    python app.py --selftest      # test interni degli indicatori

SU RENDER (vedi render.yaml): legge PORT, si mette in ascolto su 0.0.0.0, DATA_DIR per il disco persistente,
    DASH_PASSWORD (+ DASH_USER, default 'admin') protegge la dashboard con password, /healthz per l'health check.

FONTI DATI (tutte gratuite, senza chiavi)
    Cripto            Bitget futures USDT (candele 15m, ticker, funding, open interest, order book)
    Azioni/Indici/MP  Yahoo Finance (candele 15m; fuori orario di borsa i segnali sono sospesi)
    Sentiment         Fear & Greed Index (alternative.me) + titoli RSS con analisi a parole chiave
    AI (opzionale)    Claude: export ANTHROPIC_API_KEY=... verifica ogni segnale forte e lo conferma o lo scarta
    Telegram (opz.)   export TELEGRAM_TOKEN=... TELEGRAM_CHAT_ID=...  per ricevere i TOP Entry

NOTA ONESTA: nessun sistema produce segnali "esatti". Questo scanner misura da solo quanto sbaglia:
il "Track record reale" della dashboard valuta ogni segnale emesso con i prezzi veri successivi,
e --backtest fa lo stesso sullo storico. Usa quei numeri prima di rischiare denaro.
"""
import argparse, base64, hmac, json, math, os, random, re, signal as _signal, sys, threading, time
import urllib.error, urllib.parse, urllib.request
import xml.etree.ElementTree as ET
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from email.utils import parsedate_to_datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.environ.get("DATA_DIR") or os.path.join(HERE, "data")   # su Render: punta al disco persistente (es. /var/data)
try:
    os.makedirs(DATA, exist_ok=True)
except OSError:
    DATA = os.path.join("/tmp", "scanner-data")
    os.makedirs(DATA, exist_ok=True)

# ----------------------------------------------------------------------------- configurazione
VALID = 45 * 60            # validità dell'entrata (secondi)
HORIZON = 6 * 3600         # orizzonte massimo per valutare l'esito di un segnale
MIN_CONF = 60              # confidenza minima per un segnale operativo
TOP_CONF = 80              # soglia TOP Entry (diamante)
AI_MIN_CONF = int(os.environ.get("AI_MIN_CONF", "75"))   # da qui in su il segnale passa dalla verifica AI
AI_MAX_PER_CYCLE = 3
TG_MIN_CONF = int(os.environ.get("TG_MIN_CONF", "80"))
MIN_VOL_USDT = 5_000_000   # liquidità minima 24h (cripto)
TFW = {15: .30, 60: .40, 240: .30}
# Time frame operativo del singolo segnale: etichetta, stile, "tempo utile di ingresso" (finestra in cui l'entrata è valida)
# e orizzonte entro cui si valuta l'esito (TP1/SL) per il track record.
TFINFO = {15: dict(label="15 MIN", short="15m", style="Scalping", valid=20 * 60, horizon=3 * 3600),
          60: dict(label="1 ORA", short="1h", style="Intraday", valid=45 * 60, horizon=8 * 3600),
          240: dict(label="4 ORE", short="4h", style="Swing", valid=90 * 60, horizon=24 * 3600)}
W = {"trend": .30, "rsi": .20, "macd": .25, "bb": .10, "vol": .15}

# sym, nome, classe, simbolo fonte (Bitget o Yahoo), prezzo demo, volatilità demo (candela 1h)
UNIVERSE = [
    ("BTC", "Bitcoin", "cry", "BTCUSDT", 95200, .0075), ("ETH", "Ethereum", "cry", "ETHUSDT", 3320, .0095),
    ("SOL", "Solana", "cry", "SOLUSDT", 182, .012), ("BNB", "BNB", "cry", "BNBUSDT", 624, .008),
    ("XRP", "XRP", "cry", "XRPUSDT", 2.41, .012), ("ADA", "Cardano", "cry", "ADAUSDT", .71, .012),
    ("DOGE", "Dogecoin", "cry", "DOGEUSDT", .184, .014), ("AVAX", "Avalanche", "cry", "AVAXUSDT", 38.4, .013),
    ("LINK", "Chainlink", "cry", "LINKUSDT", 17.2, .012), ("DOT", "Polkadot", "cry", "DOTUSDT", 7.15, .012),
    ("LTC", "Litecoin", "cry", "LTCUSDT", 96.5, .01), ("TON", "Toncoin", "cry", "TONUSDT", 5.62, .012),
    ("SUI", "Sui", "cry", "SUIUSDT", 3.84, .015), ("NEAR", "NEAR", "cry", "NEARUSDT", 5.48, .014),
    ("APT", "Aptos", "cry", "APTUSDT", 9.2, .014), ("ARB", "Arbitrum", "cry", "ARBUSDT", .62, .014),
    ("AAPL", "Apple", "stk", "AAPL", 226.4, .0045), ("MSFT", "Microsoft", "stk", "MSFT", 432.8, .0042),
    ("NVDA", "NVIDIA", "stk", "NVDA", 141.2, .0075), ("TSLA", "Tesla", "stk", "TSLA", 262.5, .0095),
    ("AMZN", "Amazon", "stk", "AMZN", 201.3, .005), ("GOOGL", "Alphabet", "stk", "GOOGL", 176.8, .0048),
    ("META", "Meta", "stk", "META", 583.1, .0058), ("AMD", "AMD", "stk", "AMD", 152.7, .0075),
    ("NFLX", "Netflix", "stk", "NFLX", 705.4, .0062), ("JPM", "JPMorgan", "stk", "JPM", 231.6, .0042),
    ("SPX", "S&P 500", "stk", "^GSPC", 5812, .0025), ("NDX", "Nasdaq 100", "stk", "^NDX", 20540, .0032),
    ("DAX", "DAX 40", "stk", "^GDAXI", 19480, .0028), ("FTMIB", "FTSE MIB", "stk", "FTSEMIB.MI", 34120, .0027),
    ("XAU", "Oro", "com", "GC=F", 2712, .003), ("XAG", "Argento", "com", "SI=F", 32.4, .0062),
    ("WTI", "Petrolio WTI", "com", "CL=F", 72.4, .0078), ("BRENT", "Petrolio Brent", "com", "BZ=F", 76.1, .0075),
    ("NG", "Gas naturale", "com", "NG=F", 2.64, .011), ("HG", "Rame", "com", "HG=F", 4.31, .0055),
    ("WHEAT", "Grano", "com", "ZW=F", 592, .0072), ("COFFEE", "Caffè", "com", "KC=F", 3.05, .0085),
]
ALIASES = {
    "BTC": ["bitcoin", "btc"], "ETH": ["ethereum", "ether", "eth"], "SOL": ["solana"], "BNB": ["bnb", "binance coin"],
    "XRP": ["xrp", "ripple"], "ADA": ["cardano"], "DOGE": ["dogecoin", "doge"], "AVAX": ["avalanche", "avax"],
    "LINK": ["chainlink"], "DOT": ["polkadot"], "LTC": ["litecoin"], "TON": ["toncoin"], "SUI": ["sui network", "sui token"],
    "NEAR": ["near protocol"], "APT": ["aptos"], "ARB": ["arbitrum"],
}
POS_W = ["surge", "rally", "soar", "gain", "bullish", "record high", "all-time high", "approval", "approves", "approved", "adopt",
         "inflow", "breakout", "jump", "rise", "rises", "upgrade", "beat", "beats", "profit", "growth", "accumulat", "partnership",
         "launch", "recover", "rebound", "boost", "optimis", "strong", "buy rating", "outperform"]
NEG_W = ["crash", "plunge", "drop", "fall", "falls", "bearish", "hack", "exploit", "lawsuit", "sues", "ban", "outflow", "liquidat",
         "sell-off", "selloff", "downgrade", "miss", "misses", "loss", "fraud", "probe", "investigation", "decline", "slump",
         "warning", "weak", "fear", "tumble", "cut", "layoff", "recession", "default", "bankrupt", "underperform"]

clamp = lambda x, a, b: max(a, min(b, x))


def fnum(x, d=0.0):
    try:
        return float(x)
    except (TypeError, ValueError):
        return d


class Clock:
    off = 0.0

    def now(self):
        return time.time() + self.off


CLOCK = Clock()


def log(msg):
    print(time.strftime("%H:%M:%S"), msg, flush=True)


# ----------------------------------------------------------------------------- HTTP
UA = "Mozilla/5.0 (X11; Linux x86_64) SuperScanner/1.0"


def http_get(url, headers=None, timeout=12, tries=2):
    last = None
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA, **(headers or {})})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read()
        except Exception as e:  # rete, timeout, HTTP error
            last = e
            time.sleep(.4 * (i + 1))
    raise last


def get_json(url, **kw):
    return json.loads(http_get(url, **kw))


# ----------------------------------------------------------------------------- fonti dati
BG = "https://api.bitget.com"


def bitget_candles(sym, limit=1000):
    d = get_json(f"{BG}/api/v2/mix/market/candles?symbol={sym}&productType=USDT-FUTURES&granularity=15m&limit={limit}")
    if str(d.get("code")) != "00000":
        raise RuntimeError(f"Bitget {sym}: {d.get('msg')}")
    rows = [[int(r[0]) // 1000, fnum(r[1]), fnum(r[2]), fnum(r[3]), fnum(r[4]), fnum(r[5])] for r in d["data"]]
    rows.sort(key=lambda r: r[0])
    return rows


def bitget_tickers():
    d = get_json(f"{BG}/api/v2/mix/market/tickers?productType=USDT-FUTURES")
    if str(d.get("code")) != "00000":
        raise RuntimeError(f"Bitget tickers: {d.get('msg')}")
    out = {}
    for t in d["data"]:
        out[t.get("symbol")] = dict(last=fnum(t.get("lastPr")), fund=fnum(t.get("fundingRate")) * 100,
                                    oi=fnum(t.get("holdingAmount")), vol=fnum(t.get("usdtVolume") or t.get("quoteVolume")),
                                    chg=fnum(t.get("change24h")))
    return out


def bitget_imbalance(sym):
    d = get_json(f"{BG}/api/v2/mix/market/merge-depth?symbol={sym}&productType=USDT-FUTURES&limit=50")
    if str(d.get("code")) != "00000":
        raise RuntimeError(f"Bitget depth {sym}: {d.get('msg')}")
    bids = sum(fnum(x[1]) for x in d["data"]["bids"][:25])
    asks = sum(fnum(x[1]) for x in d["data"]["asks"][:25])
    return (bids - asks) / (bids + asks) if bids + asks else 0.0


def yahoo_candles(ysym):
    d = get_json(f"https://query1.finance.yahoo.com/v8/finance/chart/{urllib.parse.quote(ysym)}?interval=15m&range=30d&includePrePost=false")
    r = d["chart"]["result"][0]
    q = r["indicators"]["quote"][0]
    rows = []
    for i, t in enumerate(r.get("timestamp") or []):
        o, h, l, c = q["open"][i], q["high"][i], q["low"][i], q["close"][i]
        if None in (o, h, l, c):
            continue
        rows.append([int(t), float(o), float(h), float(l), float(c), float(q["volume"][i] or 0)])
    return rows


def fetch_fng():
    d = get_json("https://api.alternative.me/fng/?limit=1")["data"][0]
    return dict(value=int(d["value"]), label=d.get("value_classification", ""))


def kw_sentiment(text):
    t = text.lower()
    p = sum(1 for w in POS_W if w in t)
    n = sum(1 for w in NEG_W if w in t)
    return clamp((p - n) / (p + n + 1.0), -1, 1) if p + n else 0.0


def parse_rss(raw, source):
    items = []
    root = ET.fromstring(raw)
    for it in root.iter("item"):
        title = (it.findtext("title") or "").strip()
        if not title:
            continue
        try:
            ts = parsedate_to_datetime(it.findtext("pubDate")).timestamp()
        except Exception:
            ts = time.time()
        items.append(dict(title=title, link=(it.findtext("link") or "").strip(), t=ts, src=source,
                          s=kw_sentiment(title + " " + (it.findtext("description") or ""))))
    return items


CRYPTO_FEEDS = [("Cointelegraph", "https://cointelegraph.com/rss"),
                ("CoinDesk", "https://www.coindesk.com/arc/outboundfeeds/rss/")]


def fetch_crypto_news():
    out = []
    for name, url in CRYPTO_FEEDS:
        try:
            out += parse_rss(http_get(url, timeout=12), name)
        except Exception as e:
            log(f"news {name}: {e}")
    if not out:
        raise RuntimeError("nessun feed news raggiungibile")
    return out


def fetch_yahoo_news(ysym):
    url = f"https://feeds.finance.yahoo.com/rss/2.0/headline?s={urllib.parse.quote(ysym)}&region=US&lang=en-US"
    return parse_rss(http_get(url, timeout=10, tries=1), "Yahoo Finance")


# ----------------------------------------------------------------------------- indicatori
def ema(a, p):
    k = 2 / (p + 1)
    o = [a[0]]
    for x in a[1:]:
        o.append(x * k + o[-1] * (1 - k))
    return o


def aggregate(c, m):
    size = m * 900
    out, cur = [], None
    for t, o, h, l, cl, v in c:
        b = t - t % size
        if cur is None or cur[0] != b:
            if cur:
                out.append(cur)
            cur = [b, o, h, l, cl, v]
        else:
            if h > cur[2]: cur[2] = h
            if l < cur[3]: cur[3] = l
            cur[4] = cl
            cur[5] += v
    if cur:
        out.append(cur)
    return out


def calc(cs):
    n = len(cs)
    c = [x[4] for x in cs]
    e20, e50, e12, e26 = ema(c, 20), ema(c, 50), ema(c, 12), ema(c, 26)
    macd = [a - b for a, b in zip(e12, e26)]
    sg = ema(macd, 9)
    hist = [a - b for a, b in zip(macd, sg)]
    rsi = [50.0] * n
    g = l = 0.0
    for i in range(1, n):
        d = c[i] - c[i - 1]
        u, dn = max(d, 0), max(-d, 0)
        if i <= 14:
            g += u / 14
            l += dn / 14
            if i == 14:
                rsi[i] = 100.0 if l == 0 else 100 - 100 / (1 + g / l)
        else:
            g = (g * 13 + u) / 14
            l = (l * 13 + dn) / 14
            rsi[i] = 100.0 if l == 0 else 100 - 100 / (1 + g / l)
    atr = [0.0] * n
    a = 0.0
    for i in range(1, n):
        tr = max(cs[i][2] - cs[i][3], abs(cs[i][2] - c[i - 1]), abs(cs[i][3] - c[i - 1]))
        if i <= 14:
            a += tr / 14
            atr[i] = a
        else:
            a = (a * 13 + tr) / 14
            atr[i] = a
    pb = [.5] * n
    for i in range(19, n):
        w = c[i - 19:i + 1]
        m = sum(w) / 20
        sd = math.sqrt(sum((x - m) ** 2 for x in w) / 20)
        pb[i] = (c[i] - (m - 2 * sd)) / (4 * sd) if sd else .5
    vr = [1.0] * n
    for i in range(20, n):
        avg = sum(cs[j][5] for j in range(i - 20, i)) / 20
        vr[i] = ((cs[i][5] + cs[i - 1][5]) / 2) / avg if avg else 1.0
    return dict(c=c, e20=e20, e50=e50, hist=hist, rsi=rsi, atr=atr, pb=pb, vr=vr)


def adx_last(cs, n=14):
    L = len(cs)
    if L < n * 2 + 2:
        return 20.0
    tr, pdm, ndm = [], [], []
    for i in range(1, L):
        up, dn = cs[i][2] - cs[i - 1][2], cs[i - 1][3] - cs[i][3]
        pdm.append(up if up > dn and up > 0 else 0)
        ndm.append(dn if dn > up and dn > 0 else 0)
        tr.append(max(cs[i][2] - cs[i][3], abs(cs[i][2] - cs[i - 1][4]), abs(cs[i][3] - cs[i - 1][4])))
    atr, p, m = sum(tr[:n]), sum(pdm[:n]), sum(ndm[:n])
    dx = []
    for i in range(n, len(tr)):
        if i > n:
            atr = atr - atr / n + tr[i]
            p = p - p / n + pdm[i]
            m = m - m / n + ndm[i]
        pi = 100 * p / atr if atr else 0
        mi = 100 * m / atr if atr else 0
        dx.append(100 * abs(pi - mi) / (pi + mi) if pi + mi else 0)
    if len(dx) < n:
        return sum(dx) / len(dx) if dx else 20.0
    a = sum(dx[:n]) / n
    for x in dx[n:]:
        a = (a * (n - 1) + x) / n
    return a


def comps(S, cs, i):
    c = S["c"][i]
    trend = clamp((S["e20"][i] - S["e50"][i]) / S["e50"][i] * 60, -1, 1) * .7 + clamp((c - S["e50"][i]) / S["e50"][i] * 40, -1, 1) * .3
    r = S["rsi"][i]
    rs = 1 - (r - 70) / 10 * 1.5 if r > 70 else -1 + (30 - r) / 10 * 1.5 if r < 30 else (r - 50) / 20
    macd = clamp(S["hist"][i] / (S["atr"][i] or c * .005) * 3, -1, 1)
    bb = clamp((S["pb"][i] - .5) * 2, -1, 1) * .8
    d = cs[i][4] - cs[i][1]
    vol = (1 if d > 0 else -1 if d < 0 else 0) * clamp(S["vr"][i] - 1, 0, 1)
    return dict(trend=trend, rsi=clamp(rs, -1, 1), macd=macd, bb=bb, vol=vol)


def score_of(cp):
    return sum(cp[k] * W[k] for k in W) * 100


def tf_analyze(cs):
    S = calc(cs)
    i = len(cs) - 1
    cp = comps(S, cs, i)
    return dict(S=S, cs=cs, cp=cp, score=score_of(cp), i=i)


def technical(c15):
    """Analisi tecnica pura (nessun dato esterno): usata sia dal live sia dal backtest."""
    if len(c15) < 130:
        return None
    tf = {15: tf_analyze(c15[-400:]), 60: tf_analyze(aggregate(c15, 4)[-400:]), 240: tf_analyze(aggregate(c15, 16)[-400:])}
    if len(tf[60]["cs"]) < 55 or len(tf[240]["cs"]) < 30:
        tf[240] = tf[240] if len(tf[240]["cs"]) >= 30 else tf[60]
    comb = sum(TFW[k] * tf[k]["score"] for k in TFW)
    S15, S60 = tf[15]["S"], tf[60]["S"]
    price = c15[-1][4]
    atr15, atr1h = S15["atr"][-1], S60["atr"][-1]
    atr4h = tf[240]["S"]["atr"][-1]
    last2 = (c15[-1][5] + c15[-2][5]) / 2
    avgv = sum(x[5] for x in c15[-22:-2]) / 20 or 0
    vrx = last2 / avgv if avgv else 1.0
    mv = abs(c15[-1][4] - c15[-1][1]) / (atr15 or 1)
    anom = f"Volumi {vrx:.1f}x sopra la media" if vrx >= 2.2 else f"Movimento anomalo {mv:.1f}σ in 15m" if mv >= 2.4 else None
    n = len(c15)
    return dict(tf=tf, comb=comb, price=price, atr15=atr15, atr1h=atr1h, atr4h=atr4h, adx=adx_last(tf[60]["cs"]), anom=anom,
                ch24=price / c15[max(0, n - 97)][4] - 1, vol24=sum(x[5] for x in c15[-96:]) * price,
                spark=[round(x, 8) for x in S15["c"][-30:]])


def trigger(T, d):
    """Cosa ha fatto scattare il segnale sul suo time frame: (etichetta, trigger confermato?)."""
    S, cs, i = T["S"], T["cs"], T["i"]
    if i < 30:
        return "Trend in corso", False
    atr = S["atr"][i] or 1e-9
    close = cs[i][4]
    prior = cs[i - 25:i - 5]
    lvl = max(c[2] for c in prior) if d > 0 else min(c[3] for c in prior)
    broke = any((c[4] - lvl) * d > 0 for c in cs[i - 4:i + 1])
    last3 = cs[i - 2:i + 1]
    near = (min(c[3] for c in last3) <= lvl + .3 * atr) if d > 0 else (max(c[2] for c in last3) >= lvl - .3 * atr)
    if broke and near and (close - lvl) * d > 0:
        return "Breakout & Retest", True
    if broke:
        return "Breakout", True
    h = S["hist"]
    if any(h[j - 1] * d <= 0 < h[j] * d for j in range(i - 2, i + 1)) and (close - S["e20"][i]) * d > 0:
        return "Trigger Confermato", True
    if abs(close - S["e20"][i]) <= .6 * atr and (S["e20"][i] - S["e50"][i]) * d > 0:
        return "Pullback su EMA20", True
    return "Continuazione di trend", False


def finalize(t, ns=0.0, ob=0.0, fund=0.0, tradable=True):
    comb = t["comb"] + 6 * ns + 5 * ob
    agree = sum(TFW[k] for k in TFW if abs(t["tf"][k]["score"]) > 8 and (t["tf"][k]["score"] > 0) == (comb > 0))
    conf = clamp(round(abs(comb) * 1.15 + agree * 35 - 10), 0, 99)
    d = 1 if comb >= 0 else -1
    if t["adx"] < 15:
        conf = round(conf * .85)
    if (d > 0 and fund > .05) or (d < 0 and fund < -.05):
        conf -= 5
    conf = int(clamp(conf, 0, 99))
    raw = d if (abs(comb) >= 28 and conf >= MIN_CONF and tradable) else 0
    p = t["price"]
    # time frame esatto del segnale: quello allineato alla direzione con il punteggio più forte (a parità, il più lungo)
    aligned = [k for k in TFW if abs(t["tf"][k]["score"]) > 8 and (t["tf"][k]["score"] > 0) == (comb > 0)]
    tfm = max(aligned, key=lambda k: (abs(t["tf"][k]["score"]) * (1 + TFW[k]), k)) if aligned else 60
    if not p:
        sl_pct = .01
    elif tfm == 15:
        sl_pct = clamp(1.5 * t["atr15"] / p, .004, .025)
    elif tfm == 60:
        sl_pct = clamp(max(1.5 * t["atr15"], .8 * t["atr1h"]) / p, .006, .04)
    else:
        sl_pct = clamp(1.2 * t["atr4h"] / p, .01, .06)
    hi = int(clamp(math.floor(1 / (8 * sl_pct)), 2, 25))
    trig, trig_ok = trigger(t["tf"][tfm], d)
    return dict(comb=comb, agree=agree, conf=conf, dir=d, raw=raw, sl_pct=sl_pct, lev=[max(1, round(hi * .7)), hi], tfm=tfm, trig=trig, trig_ok=trig_ok)


# ----------------------------------------------------------------------------- esiti segnali
def evaluate(s, cs, price):
    """'SL' / 'TP1' / None usando i massimi/minimi reali delle candele aperte dopo l'entrata (SL prima del TP nella stessa candella)."""
    d = s["dir"]
    for c in cs[-110:]:
        if c[0] < s["since"]:
            continue
        lo, hi = c[3], c[2]
        if d > 0:
            if lo <= s["sl"]: return "SL"
            if hi >= s["tp1"]: return "TP1"
        else:
            if hi >= s["sl"]: return "SL"
            if lo <= s["tp1"]: return "TP1"
    if d * (price - s["sl"]) <= 0: return "SL"
    if d * (price - s["tp1"]) >= 0: return "TP1"
    return None


def make_levels(price, d, sl_pct):
    return dict(entry=price, sl=price * (1 - d * sl_pct), tp1=price * (1 + d * 1.5 * sl_pct), tp2=price * (1 + d * 3 * sl_pct), sl_pct=sl_pct)


# ----------------------------------------------------------------------------- AI (Claude)
AI_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
AI_MODEL = os.environ.get("CLAUDE_MODEL", "claude-sonnet-5-5")


def claude(system, user, max_tokens=500):
    body = json.dumps(dict(model=AI_MODEL, max_tokens=max_tokens, system=system,
                           messages=[dict(role="user", content=user)])).encode()
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=body, method="POST",
                                 headers={"x-api-key": AI_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json"})
    with urllib.request.urlopen(req, timeout=40) as r:
        d = json.loads(r.read())
    return "".join(b.get("text", "") for b in d.get("content", []))


def extract_json(txt):
    a, b = txt.find("{"), txt.rfind("}")
    return json.loads(txt[a:b + 1])


AI_SYS = ("Sei un analista quantitativo prudente. Ricevi un segnale di trading generato da un motore tecnico, con indicatori, "
          "notizie e dati di mercato reali. Devi decidere se CONFERMARE o SCARTARE il segnale cercando attivamente motivi per cui "
          "potrebbe essere sbagliato (trend contrario sui timeframe alti, ipercomprato/ipervenduto, funding affollato, notizie "
          "contrarie, volumi deboli, rischio di inversione). Non inventare dati che non ti sono stati forniti. "
          'Rispondi SOLO con JSON: {"verdict":"CONFERMA"|"SCARTA","adjust":<intero da -15 a 5>,"risk":"BASSO"|"MEDIO"|"ALTO","reason":"max 2 frasi in italiano"}')


# ----------------------------------------------------------------------------- scanner
class Scanner:
    def __init__(self, args):
        self.args = args
        self.demo = args.demo
        self.lock = threading.RLock()
        self.pool = ThreadPoolExecutor(max_workers=8)
        self.assets = {}
        for sym, name, cls, src, dp, dv in UNIVERSE:
            self.assets[sym] = dict(sym=sym, name=name, cls=cls, src=src, dprice=dp, dvol=dv / 2, candles=[], price=0.0,
                                    ns=0.0, ob=0.0, fund=0.0, oi=0.0, oi_hist=deque(maxlen=400), vol24q=0.0, news=[], sig=None, cool=0.0,
                                    t=None, fin=None, open=True, lastlog=0)
        self.status = {k: dict(ok=None, err="", t=0) for k in ("bitget", "yahoo", "news", "fng", "ai")}
        self.events = deque(maxlen=100)
        self.sent_hist = deque(maxlen=240)
        self.fng = None
        self.ai_summary = None
        self.history = []
        self.snapshot_bytes = b"{}"
        self.cycles = 0
        self.t_last = dict(crypto=0, yahoo=0, news=0, fng=0, depth=0, save=0, summary=0)
        self.ai_enabled = bool(AI_KEY) and not args.no_ai
        self.tg_token = os.environ.get("TELEGRAM_TOKEN", "")
        self.tg_chat = os.environ.get("TELEGRAM_CHAT_ID", "")
        self.rnd = random.Random(20261105)
        self.mood = {"cry": 0.0, "stk": 0.0, "com": 0.0}
        self.tick_count = 0
        self.load_state()

    # --- stato persistente
    def load_state(self):
        try:
            with open(os.path.join(DATA, "state.json")) as f:
                st = json.load(f)
            self.history = st.get("history", [])[-500:]
            for sym, s in st.get("sigs", {}).items():
                if sym in self.assets and s.get("state") == "ACTIVE" and CLOCK.now() < s.get("expires", s["since"] + VALID) and not self.demo:
                    self.assets[sym]["sig"] = s
        except Exception:
            pass

    def save_state(self):
        if self.demo:
            return
        try:
            with self.lock:
                st = dict(history=self.history[-500:], sigs={a["sym"]: a["sig"] for a in self.assets.values() if a["sig"]})
            tmp = os.path.join(DATA, "state.json.tmp")
            with open(tmp, "w") as f:
                json.dump(st, f)
            os.replace(tmp, os.path.join(DATA, "state.json"))
        except Exception as e:
            log(f"salvataggio stato: {e}")

    def mark(self, k, ok, err=""):
        self.status[k] = dict(ok=ok, err=str(err)[:120], t=CLOCK.now())

    def event(self, typ, txt):
        self.events.appendleft(dict(t=CLOCK.now(), type=typ, txt=txt))
        log(f"[{typ}] {txt}")

    # --- acquisizione dati reali
    def refresh_crypto(self, full):
        cr = [a for a in self.assets.values() if a["cls"] == "cry"]
        ok = 0
        try:
            tk = bitget_tickers()
            for a in cr:
                t = tk.get(a["src"])
                if t:
                    a["fund"], a["vol24q"] = t["fund"], t["vol"]
                    a["oi_hist"].append((CLOCK.now(), t["oi"]))
                    a["oi"] = t["oi"]
        except Exception as e:
            self.mark("bitget", False, e)

        def one(a):
            rows = bitget_candles(a["src"], 1000 if full or len(a["candles"]) < 300 else 8)
            with self.lock:
                self.merge(a, rows)
            return True
        for a, fu in [(a, self.pool.submit(one, a)) for a in cr]:
            try:
                fu.result()
                ok += 1
            except Exception as e:
                self.mark("bitget", False, f"{a['sym']}: {e}")
        if ok:
            self.mark("bitget", True)
        return ok

    def refresh_depth(self):
        cr = [a for a in self.assets.values() if a["cls"] == "cry" and a["candles"]]
        futs = [(a, self.pool.submit(bitget_imbalance, a["src"])) for a in cr]
        for a, fu in futs:
            try:
                a["ob"] = fu.result()
            except Exception:
                pass

    def refresh_yahoo(self):
        st = [a for a in self.assets.values() if a["cls"] != "cry"]
        futs = [(a, self.pool.submit(yahoo_candles, a["src"])) for a in st]
        ok = 0
        for a, fu in futs:
            try:
                rows = fu.result()
                if rows:
                    with self.lock:
                        a["candles"] = rows[-1100:]
                        a["price"] = rows[-1][4]
                    ok += 1
            except Exception as e:
                self.mark("yahoo", False, f"{a['sym']}: {e}")
        if ok >= len(st) // 2:
            self.mark("yahoo", True)
        return ok

    def merge(self, a, rows):
        cs = a["candles"]
        if not cs:
            a["candles"] = rows[-1100:]
        else:
            for r in rows:
                if r[0] == cs[-1][0]:
                    cs[-1] = r
                elif r[0] > cs[-1][0]:
                    cs.append(r)
            del cs[:-1100]
        a["price"] = a["candles"][-1][4]

    def refresh_news(self):
        try:
            items = fetch_crypto_news()
        except Exception as e:
            self.mark("news", False, e)
            items = []
        now = CLOCK.now()
        items = [i for i in items if now - i["t"] < 36 * 3600]
        mkt = (sum(i["s"] for i in items) / len(items)) if items else 0.0
        for a in self.assets.values():
            if a["cls"] != "cry":
                continue
            pat = re.compile(r"\b(" + "|".join(re.escape(x) for x in ALIASES.get(a["sym"], [a["sym"].lower()])) + r")\b", re.I)
            mine = sorted([i for i in items if pat.search(i["title"])], key=lambda i: -i["t"])[:6]
            a["news"] = mine
            own = sum(i["s"] for i in mine) / len(mine) if mine else 0.0
            a["ns"] = clamp(.7 * own + .3 * mkt if mine else .3 * mkt, -1, 1)
            a["mkt_news"] = sorted(items, key=lambda i: -i["t"])[:3]
        futs = [(a, self.pool.submit(fetch_yahoo_news, a["src"])) for a in self.assets.values() if a["cls"] != "cry"]
        got = 0
        for a, fu in futs:
            try:
                its = [i for i in fu.result() if now - i["t"] < 72 * 3600]
                its.sort(key=lambda i: -i["t"])
                a["news"] = its[:6]
                a["ns"] = clamp(sum(i["s"] for i in its[:6]) / len(its[:6]), -1, 1) if its else 0.0
                got += 1
            except Exception:
                pass
        if items or got:
            self.mark("news", True)

    def refresh_fng(self):
        try:
            self.fng = fetch_fng()
            self.mark("fng", True)
        except Exception as e:
            self.mark("fng", False, e)

    # --- demo (dati sintetici)
    def demo_init(self):
        r = self.rnd
        now = int(CLOCK.now())
        for a in self.assets.values():
            a["per"] = (40 + r.random() * 50) * 4
            a["ph"] = r.random() * 6.28
            a["amp"] = .25 + r.random() * .5
            a["beta"] = .7 + r.random() * .6
            a["pos"] = 1000
            a["v0"] = (1e4 if a["cls"] == "cry" else 6e4 if a["cls"] == "stk" else 2e4) * (.5 + r.random())
            n = 1000
            rets = [a["amp"] * math.sin(2 * math.pi * i / a["per"] + a["ph"]) * a["dvol"] * .5 + a["dvol"] * r.gauss(0, 1) * .9 for i in range(n)]
            path = [1.0]
            for x in rets:
                path.append(path[-1] * math.exp(x))
            k = a["dprice"] / path[n]
            end = now - now % 900
            cs = []
            for i in range(n):
                o, c = path[i] * k, path[i + 1] * k
                cs.append([end - (n - i) * 900, o, max(o, c) * (1 + abs(r.gauss(0, 1)) * a["dvol"] * .35), min(o, c) * (1 - abs(r.gauss(0, 1)) * a["dvol"] * .35), c,
                           a["v0"] * (.55 + r.random() * .9) * (1 + abs(rets[i]) / a["dvol"] * .35)])
            a["candles"], a["price"] = cs, cs[-1][4]
            a["vol24q"] = 5e7
        for k in ("bitget", "yahoo", "news", "fng"):
            self.mark(k, True)
        self.fng = dict(value=48, label="Neutral")

    def demo_tick(self):
        r = self.rnd
        g = r.gauss(0, 1)
        for k in self.mood:
            self.mood[k] = .9 * self.mood[k] + .43 * (.5 * g + .87 * r.gauss(0, 1))
        for a in self.assets.values():
            L = a["candles"][-1]
            dr = a["amp"] * math.sin(2 * math.pi * a["pos"] / a["per"] + a["ph"]) * a["dvol"] * .5 / 15
            a["pos"] += 1 / 15
            ret = dr + a["dvol"] / math.sqrt(15) * (.9 * r.gauss(0, 1) + .14 * self.mood[a["cls"]] * a["beta"])
            np_ = L[4] * math.exp(ret)
            L[4], L[2], L[3] = np_, max(L[2], np_), min(L[3], np_)
            L[5] += a["v0"] / 15 * (.7 + r.random() * .6)
            a["price"] = np_
        self.tick_count += 1
        if self.tick_count % 15 == 0:
            for a in self.assets.values():
                L = a["candles"][-1]
                a["candles"].append([int(CLOCK.now()) - int(CLOCK.now()) % 900, L[4], L[4], L[4], L[4], 0])
                del a["candles"][:-1100]
        CLOCK.off += 60

    HEAD = {"p": ["Segnali di accumulo da parte degli investitori istituzionali", "Volumi in crescita con momentum positivo", "Revisioni al rialzo da parte degli analisti"],
            "n": ["Prese di profitto in corso dopo il rialzo", "Volumi in calo, la spinta si indebolisce", "Pressione di vendita sui massimi recenti"],
            "z": ["Mercato in attesa dei dati macro", "Volumi nella media, range stretto"]}

    def demo_meta(self, a, comb):
        r = self.rnd
        a["ns"] = clamp(.94 * a["ns"] + .06 * (math.tanh(comb / 35) * .9 + r.gauss(0, .7)), -1, 1)
        a["ob"] = clamp(.8 * a["ob"] + .2 * (math.tanh(comb / 40) * .6 + r.gauss(0, .4)), -1, 1)
        a["fund"] = .01 + .025 * math.tanh(comb / 50) + .004 * r.gauss(0, 1)
        k = "p" if a["ns"] > .25 else "n" if a["ns"] < -.25 else "z"
        if not a["news"] or a["news"][0].get("k") != k:
            a["news"] = [dict(title=f"{a['sym']}: {r.choice(self.HEAD[k])}", link="", t=CLOCK.now() - r.randint(60, 3000), src="demo", s=a["ns"], k=k)]
        a["oi_hist"].append((CLOCK.now(), 1e6 * (1 + a["oi"])))
        a["oi"] = a["oi"] * .95 + (comb * .0005 + r.gauss(0, .01)) * .05

    # --- segnali
    def tradable(self, a, now):
        if a["cls"] == "cry":
            return a["vol24q"] >= MIN_VOL_USDT or self.demo
        return now - a["candles"][-1][0] <= 3600 + 900 or self.demo

    def analyze_asset(self, a, now):
        t = technical(a["candles"])
        if not t:
            return
        t["price"] = a["price"] or t["price"]
        a["open"] = self.tradable(a, now)
        a["t"] = t
        a["fin"] = finalize(t, a["ns"], a["ob"] if a["cls"] == "cry" else 0.0, a["fund"] if a["cls"] == "cry" else 0.0, a["open"])

    def new_sig(self, a, now):
        f, p = a["fin"], a["price"]
        lv = make_levels(p, f["raw"], f["sl_pct"])
        tfm = f["tfm"]
        info = TFINFO[tfm]
        step = tfm * 60
        sig = dict(id=f"{a['sym']}-{int(now)}", dir=f["raw"], since=now, tfm=tfm, valid=info["valid"], expires=now + info["valid"],
                   tf_close=(int(now) // step + 1) * step, trig=f["trig"], trig_ok=f["trig_ok"], conf0=f["conf"], lev=f["lev"], state="ACTIVE", ai=None, ai_pending=False, vetoed=False, notified=False, **lv)
        a["sig"] = sig
        self.history.append(dict(id=sig["id"], sym=a["sym"], dir=sig["dir"], since=now, entry=p, sl=sig["sl"], tp1=sig["tp1"], tp2=sig["tp2"],
                                 tfm=tfm, horizon=info["horizon"], conf=f["conf"], status="OPEN", r=None, closed=None, ai=None))
        self.history = self.history[-500:]
        self.event("TOP" if f["conf"] >= TOP_CONF else ("LONG" if sig["dir"] > 0 else "SHORT"),
                   f"{a['sym']} {'LONG' if sig['dir'] > 0 else 'SHORT'} · TF {info['short']} · confidenza {f['conf']}% · entrata {p:.6g}")
        if not self.ai_enabled and f["conf"] >= TG_MIN_CONF:
            self.notify(a, sig)

    def update_signal(self, a, now):
        f, s = a["fin"], a["sig"]
        if s and s["state"] == "ACTIVE":
            out = evaluate(s, a["candles"], a["price"])
            if out:
                s["state"] = "STOPPED" if out == "SL" else "TARGET"
                a["cool"] = now + 1200
                self.event("STOP" if out == "SL" else "TP", f"{a['sym']} {'stop loss colpito' if out == 'SL' else 'TP1 raggiunto'} a {a['price']:.6g}")
            elif now >= s.get("expires", s["since"] + VALID):
                s["state"] = "EXPIRED"
                a["cool"] = now + 300
            elif f["raw"] and f["raw"] != s["dir"] and f["conf"] >= 65:
                self.new_sig(a, now)
        elif f["raw"] and now >= a["cool"]:
            self.new_sig(a, now)

    def update_history(self, now):
        for h in self.history:
            if h["status"] != "OPEN":
                continue
            a = self.assets.get(h["sym"])
            if not a or not a["candles"]:
                continue
            out = evaluate(h, a["candles"], a["price"])
            risk = abs(h["entry"] - h["sl"]) or 1e-9
            if out == "SL":
                h.update(status="SL", r=-1.0, closed=now)
            elif out == "TP1":
                h.update(status="TP1", r=1.5, closed=now)
            elif now - h["since"] >= h.get("horizon", HORIZON):
                h.update(status="TIMEOUT", r=round(clamp(h["dir"] * (a["price"] - h["entry"]) / risk, -1, 1.5), 2), closed=now)

    def track(self):
        done = [h for h in self.history if h["status"] in ("SL", "TP1", "TIMEOUT")]
        w = sum(1 for h in done if h["status"] == "TP1")
        l = sum(1 for h in done if h["status"] == "SL")

        def st(lst):
            ww = sum(1 for h in lst if h["status"] == "TP1")
            ll = sum(1 for h in lst if h["status"] == "SL")
            return dict(n=len(lst), win=ww, loss=ll, winrate=(ww / (ww + ll) if ww + ll else None),
                        exp_r=(sum(h["r"] for h in lst) / len(lst) if lst else None))
        by_tf = {TFINFO[k]["short"]: st([h for h in done if h.get("tfm", 60) == k]) for k in TFINFO}
        bands = {f"{lo}-{hi}": st([h for h in done if lo <= h["conf"] < hi]) for lo, hi in ((60, 70), (70, 80), (80, 101))}
        return dict(open=sum(1 for h in self.history if h["status"] == "OPEN"), **st(done), timeouts=len(done) - w - l, bands=bands, by_tf=by_tf,
                    breakeven=0.4, recent=[dict(sym=h["sym"], tf=TFINFO[h.get("tfm", 60)]["short"], dir=h["dir"], conf=h["conf"], status=h["status"], r=h["r"], t=h["since"]) for h in reversed(done[-8:])])

    # --- AI
    def top_flag(self, a):
        s = a["sig"]
        if not (s and s["state"] == "ACTIVE") or s["vetoed"]:
            return False
        if self.ai_enabled and s["ai"] is None and a["fin"]["conf"] >= AI_MIN_CONF:
            return False  # in attesa della verifica AI: niente diamante finché Claude non risponde
        adj = (s["ai"] or {}).get("adjust", 0)
        return a["fin"]["conf"] + adj >= TOP_CONF

    def ai_payload(self, a):
        t, f, s = a["t"], a["fin"], a["sig"]
        tfs = {}
        for k, nm in ((15, "15m"), (60, "1h"), (240, "4h")):
            T = t["tf"][k]
            S, i = T["S"], T["i"]
            tfs[nm] = dict(score=round(T["score"]), rsi=round(S["rsi"][i], 1), macd_hist_positivo=S["hist"][i] > 0,
                           ema20_vs_ema50_pct=round((S["e20"][i] / S["e50"][i] - 1) * 100, 2), bollinger_pctB=round(S["pb"][i], 2), volume_vs_media=round(S["vr"][i], 2))
        info = TFINFO[s.get("tfm", 60)]
        d = dict(asset=f"{a['sym']} ({a['name']})", classe=a["cls"], direzione="LONG" if s["dir"] > 0 else "SHORT", prezzo=a["price"],
                 timeframe_segnale=info["short"], stile=info["style"], tempo_utile_ingresso_min=round(s.get("valid", VALID) / 60), trigger=s.get("trig"),
                 entrata=s["entry"], stop_loss=s["sl"], tp1=s["tp1"], tp2=s["tp2"], confidenza_motore=f["conf"], score_combinato=round(f["comb"], 1),
                 allineamento_timeframe=round(f["agree"], 2), adx_1h=round(t["adx"], 1), variazione_24h_pct=round(t["ch24"] * 100, 2), timeframes=tfs,
                 sentiment_notizie=round(a["ns"], 2), titoli=[i["title"] for i in a["news"][:3]])
        if a["cls"] == "cry":
            d.update(funding_rate_pct=round(a["fund"], 4), squilibrio_order_book=round(a["ob"], 2))
        if self.fng:
            d["fear_greed"] = self.fng
        return json.dumps(d, ensure_ascii=False)

    def ai_verify(self, a, sig):
        try:
            with self.lock:
                payload = self.ai_payload(a)
            res = extract_json(claude(AI_SYS, payload, 400))
            v = "SCARTA" if str(res.get("verdict", "")).upper().startswith("SCART") else "CONFERMA"
            ai = dict(verdict=v, adjust=int(clamp(int(res.get("adjust", 0)), -15, 5)), risk=str(res.get("risk", "MEDIO")).upper(), reason=str(res.get("reason", ""))[:300], t=CLOCK.now())
            self.mark("ai", True)
        except Exception as e:
            self.mark("ai", False, e)
            ai = None
        with self.lock:
            sig["ai_pending"] = False
            if ai:
                sig["ai"] = ai
                sig["vetoed"] = ai["verdict"] == "SCARTA"
                for h in self.history:
                    if h["id"] == sig["id"]:
                        h["ai"] = ai["verdict"]
                self.event("AI", f"{a['sym']} {ai['verdict']} · {ai['reason'][:110]}")
                if not sig["vetoed"] and a["fin"]["conf"] + ai["adjust"] >= TG_MIN_CONF:
                    self.notify(a, sig)
            else:
                sig["ai"] = dict(verdict="ERRORE", adjust=0, risk="?", reason="Verifica AI non riuscita", t=CLOCK.now())

    def run_ai(self):
        if not self.ai_enabled:
            return
        n = 0
        for a in sorted(self.assets.values(), key=lambda x: -(x["fin"]["conf"] if x["fin"] else 0)):
            s = a["sig"]
            if n >= AI_MAX_PER_CYCLE:
                break
            if s and s["state"] == "ACTIVE" and s["ai"] is None and not s["ai_pending"] and a["fin"]["conf"] >= AI_MIN_CONF:
                s["ai_pending"] = True
                self.pool.submit(self.ai_verify, a, s)
                n += 1

    def run_summary(self, now):
        if not self.ai_enabled or now - self.t_last["summary"] < 1200:
            return
        self.t_last["summary"] = now
        acts = [a for a in self.assets.values() if a["sig"] and a["sig"]["state"] == "ACTIVE" and not a["sig"]["vetoed"]]
        acts.sort(key=lambda a: -a["fin"]["conf"])
        if not acts:
            return
        cls = {k: round(sum(a["fin"]["comb"] for a in self.assets.values() if a["cls"] == k and a["fin"]) / max(1, sum(1 for a in self.assets.values() if a["cls"] == k and a["fin"]))) for k in ("cry", "stk", "com")}
        d = dict(fear_greed=self.fng, forza_media_per_classe=cls, segnali=[dict(sym=a["sym"], dir=("LONG" if a["sig"]["dir"] > 0 else "SHORT"), conf=a["fin"]["conf"]) for a in acts[:8]])

        def job():
            try:
                txt = claude("Sei un analista di mercato. In massimo 70 parole, in italiano, riassumi il quadro attuale dai dati forniti: direzione prevalente, rischi, dove c'è confluenza. Non inventare notizie.",
                             json.dumps(d, ensure_ascii=False), 300).strip()
                self.ai_summary = dict(text=txt, t=CLOCK.now())
                self.mark("ai", True)
            except Exception as e:
                self.mark("ai", False, e)
        self.pool.submit(job)

    # --- Telegram
    def notify(self, a, s):
        if s["notified"] or not (self.tg_token and self.tg_chat):
            return
        s["notified"] = True
        L = s["dir"] > 0
        pc = lambda x: f"{(x / s['entry'] - 1) * s['dir'] * 100:+.2f}%"
        txt = (f"{'💎 ' if a['fin']['conf'] >= TOP_CONF else ''}{'LONG' if L else 'SHORT'} {a['sym']} — confidenza {a['fin']['conf']}%\n"
               f"Entrata market: {s['entry']:.6g}\nTP1: {s['tp1']:.6g} ({pc(s['tp1'])})\nTP2: {s['tp2']:.6g} ({pc(s['tp2'])})\n"
               f"Stop loss: {s['sl']:.6g} ({-s['sl_pct'] * 100:.2f}%)\nLeva consigliata: {s['lev'][0]}x–{s['lev'][1]}x\n"
               f"Time frame: {TFINFO[s.get('tfm', 60)]['label']} ({TFINFO[s.get('tfm', 60)]['style']}) · {s.get('trig', '')}\n"
               f"Tempo utile ingresso: {round(s.get('valid', VALID) / 60)} min (entro le {time.strftime('%H:%M', time.localtime(s.get('expires', s['since'] + VALID)))})"
               + (f"\nAI: {s['ai']['verdict']} — {s['ai']['reason']}" if s.get("ai") else ""))

        def send():
            try:
                data = urllib.parse.urlencode(dict(chat_id=self.tg_chat, text=txt)).encode()
                urllib.request.urlopen(urllib.request.Request(f"https://api.telegram.org/bot{self.tg_token}/sendMessage", data=data), timeout=15).read()
            except Exception as e:
                log(f"telegram: {e}")
        self.pool.submit(send)

    # --- snapshot per la dashboard
    def build_snapshot(self, now):
        out = []
        for a in self.assets.values():
            if not a["fin"] or not a["t"]:
                continue
            t, f, s = a["t"], a["fin"], a["sig"]
            tf = {}
            for k in (15, 60, 240):
                T = t["tf"][k]
                S, i = T["S"], T["i"]
                tf[str(k)] = dict(score=round(T["score"], 1), rsi=round(S["rsi"][i], 1), hist=S["hist"][i] / a["price"] * 1e4 if a["price"] else 0,
                                  e2050=S["e20"][i] / S["e50"][i] - 1, pb=round(S["pb"][i], 2), vr=round(S["vr"][i], 2), atrp=S["atr"][i] / a["price"] if a["price"] else 0)
            sg = None
            if s:
                sg = {k: s[k] for k in ("id", "dir", "since", "entry", "sl", "tp1", "tp2", "sl_pct", "lev", "state", "ai", "ai_pending", "vetoed",
                                        "tfm", "valid", "expires", "tf_close", "trig", "trig_ok")}
                # di quanto il prezzo ha già corso dall'entrata, in multipli della distanza dallo stop (R): oltre 0,35 R inseguire non conviene
                sg["slip"] = round(s["dir"] * (a["price"] / s["entry"] - 1) / s["sl_pct"], 2) if a["price"] and s["entry"] and s["sl_pct"] else 0
            oi_chg = None
            if len(a["oi_hist"]) > 3 and a["oi_hist"][0][1]:
                oi_chg = (a["oi_hist"][-1][1] / a["oi_hist"][0][1] - 1, (a["oi_hist"][-1][0] - a["oi_hist"][0][0]) / 60)
            head = a["news"][0] if a["news"] else None
            out.append(dict(sym=a["sym"], name=a["name"], cls=a["cls"], price=a["price"], ch24=t["ch24"], vol24=t["vol24"], conf=f["conf"], comb=round(f["comb"], 1),
                            dir=f["dir"], raw=f["raw"], tfm=f["tfm"], trig=f["trig"], agree=f["agree"], adx=round(t["adx"], 1), tf=tf, sig=sg, top=self.top_flag(a), anom=t["anom"], spark=t["spark"],
                            sl_pct=f["sl_pct"], lev=f["lev"], open=a["open"],
                            news=dict(ns=round(a["ns"], 2), head=(head["title"] if head else None), link=(head["link"] if head else None), src=(head["src"] if head else None),
                                      age=(round((now - head["t"]) / 60) if head else None), n=len(a["news"])),
                            flows=dict(bull=round(clamp(50 + f["comb"] * .4 + a["ns"] * 15, 8, 92), 1), ob=round(a["ob"], 3) if a["cls"] == "cry" else None,
                                       fund=round(a["fund"], 4) if a["cls"] == "cry" else None, oi=oi_chg, vol=a["vol24q"] if a["cls"] == "cry" else None)))
        cls = {}
        for k in ("cry", "stk", "com"):
            l = [x["comb"] for x in out if x["cls"] == k]
            cls[k] = sum(l) / len(l) if l else 0.0
        self.sent_hist.append(dict(t=now, v=[cls["cry"], cls["stk"], cls["com"]]))
        snap = dict(server_time=now, mode="demo" if self.demo else "live", cycles=self.cycles, status=self.status, fng=self.fng, ai_enabled=self.ai_enabled,
                    ai_summary=self.ai_summary, track=self.track(), assets=out, log=list(self.events)[:30], sent=list(self.sent_hist),
                    config=dict(valid=VALID, tfinfo={str(k): v for k, v in TFINFO.items()}, late=.35, top=TOP_CONF, min=MIN_CONF, model=AI_MODEL if self.ai_enabled else None, tg=bool(self.tg_token and self.tg_chat)))
        self.snapshot_bytes = json.dumps(snap, ensure_ascii=False).encode()

    def chart(self, sym, tf):
        a = self.assets.get(sym)
        if not a or not a["candles"]:
            return None
        with self.lock:
            c15 = list(a["candles"])
        cs = c15[-400:] if tf == 15 else aggregate(c15, tf // 15)[-400:]
        S = calc(cs)
        n = len(cs)
        N = min(120, n)
        sc = [round(score_of(comps(S, cs, i)), 1) if i >= 50 else 0 for i in range(n - N, n)]
        sl = slice(n - N, n)
        return dict(t=[c[0] for c in cs[sl]], o=[c[1] for c in cs[sl]], h=[c[2] for c in cs[sl]], l=[c[3] for c in cs[sl]], c=[c[4] for c in cs[sl]],
                    v=[c[5] for c in cs[sl]], e20=S["e20"][sl], e50=S["e50"][sl], rsi=[round(x, 1) for x in S["rsi"][sl]], score=sc)

    # --- ciclo principale
    def cycle(self):
        now = CLOCK.now()
        a = self.args
        first = self.cycles == 0
        if self.demo:
            if first:
                self.demo_init()
            else:
                self.demo_tick()
            now = CLOCK.now()
        else:
            tl = self.t_last
            if first or now - tl["crypto"] >= a.interval:
                self.refresh_crypto(first)
                tl["crypto"] = now
            if first or now - tl["depth"] >= 60:
                self.refresh_depth()
                tl["depth"] = now
            if first or now - tl["yahoo"] >= 300:
                self.refresh_yahoo()
                tl["yahoo"] = now
            if first or now - tl["news"] >= 600:
                self.refresh_news()
                tl["news"] = now
            if first or now - tl["fng"] >= 900:
                self.refresh_fng()
                tl["fng"] = now
        with self.lock:
            for x in self.assets.values():
                if len(x["candles"]) >= 130:
                    self.analyze_asset(x, now)
                    if self.demo and x["fin"]:
                        self.demo_meta(x, x["fin"]["comb"])
                    if x["fin"]:
                        self.update_signal(x, now)
            self.update_history(now)
            self.run_ai()
            self.run_summary(now)
            self.cycles += 1
            self.build_snapshot(now)
        if self.cycles == 1 and not self.demo:
            log("Fonti dopo il primo ciclo: " + ", ".join(f"{k}={'ok' if v['ok'] else ('ERRORE: ' + v['err'] if v['ok'] is False else 'n/d')}" for k, v in self.status.items()))
        if not self.demo and now - self.t_last["save"] > 60:
            self.t_last["save"] = now
            self.save_state()

    def loop(self):
        while True:
            t0 = time.time()
            try:
                self.cycle()
            except Exception as e:
                import traceback
                traceback.print_exc()
                log(f"errore ciclo: {e}")
            time.sleep(max(.5, self.args.interval - (time.time() - t0)))


# ----------------------------------------------------------------------------- server HTTP
SC = None


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send(self, code, body, ctype="application/json; charset=utf-8"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def authed(self):
        pw = os.environ.get("DASH_PASSWORD")
        if not pw:
            return True
        h = self.headers.get("Authorization", "")
        if h.startswith("Basic "):
            try:
                user, _, pas = base64.b64decode(h[6:]).decode().partition(":")
            except Exception:
                return False
            return hmac.compare_digest(pas, pw) and hmac.compare_digest(user, os.environ.get("DASH_USER", "admin"))
        return False

    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        if u.path == "/healthz":
            return self.send(200, b"ok", "text/plain; charset=utf-8")
        if not self.authed():
            self.send_response(401)
            self.send_header("WWW-Authenticate", 'Basic realm="Super Scanner"')
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        if u.path in ("/", "/index.html", "/dashboard.html"):
            try:
                with open(os.path.join(HERE, "dashboard.html"), "rb") as f:
                    return self.send(200, f.read(), "text/html; charset=utf-8")
            except OSError:
                return self.send(200, embedded_dashboard(), "text/html; charset=utf-8")
        if u.path == "/api/signals":
            return self.send(200, SC.snapshot_bytes)
        if u.path == "/api/chart":
            q = urllib.parse.parse_qs(u.query)
            tf = int(q.get("tf", ["15"])[0])
            d = SC.chart(q.get("sym", [""])[0], tf if tf in (15, 60, 240) else 15)
            return self.send(200 if d else 404, json.dumps(d or {"error": "asset non trovato"}).encode())
        self.send(404, b'{"error":"not found"}')


# ----------------------------------------------------------------------------- dashboard incorporata
# Se accanto ad app.py esiste un file dashboard.html viene usato quello (puoi modificarlo); altrimenti questa copia.
DASHBOARD_B64 = (
    "eNrNvVtvI9mWJvaevyJSlZXBSAUpkromqZBaqVRWqTtvTqnq1Gk5UQqSQTKOeKuIICUlk0C/DDADNNzATHsM2AZ6Xsawnwz7xTbg"
    "J/c/OX/A/RPmW2vvHbHjQorKU2PPOZVixI5932uv215r7cOnnXE7up94Rj8aDo6eHNKPMXBHPWfDjzYowXM7+Bl6kWu0+24QepGz"
    "MY265YMNlTxyh56zMfO928k4iDaM9ngUeSNku/U7Ud/peDO/7ZX5xfZHfuS7g3LYdgeeU7NVqXLXj5z2eOYFVG3kRwPv6GI68QLj"
    "ou2ORl5wuCUSnxwO/NGNEXgDZ2MSeGhr5LXRaD/wus5GP4omYWNrq4suhJXeeNwbeO7EDyvt8XDjcWXDyI38Nhc02sE4DMeB3/NH"
    "qpKH29tqh2H9uOsO/cG9c+qPvniDxm2vH/3VbrXa3MO//Wr1ufz81170KnD9Ubj5bjwai2w7yLKbznYxDlzxcRsfdkQ9zzt+OBm4"
    "90546042xOjC6H7ghX3P4zXkt6MnWy+Mt+79eBo1jNDvjdyB0fHCm4rxiifYuPzw0cCyBb4X2kaE8XlYycF0OAqNUs+d9rzNmTvw"
    "O350bxsj7zbc7A7Gt8jq3XntaeSPR5sn55b9xDAYTiJj04j8odcNAB1G5LYGnm2cnKN7bscf9fAVTwMjCtw2rUh7HHRsIxRrrbIP"
    "3eDGiwyCCoKTivFi60kjGI+jOVpB38YB4KjvDb1GBzmbSCyXW73Gd9W96kG13cTbxB1h1r+rtmvV2n6cUG98V6vV9ut1SsFqenhv"
    "1Xe2t9U7MtTd7f3dqqgT6934zmt7Bx2uFK/I4G677ZZL78NphBr2Wvt7By/pvRf4nUbQa7mlWr1q13bwb79qV6p7lqiuNx50Gt91"
    "9lrVHa6P3svhuBuJQvXaDgrs2fivUtuxKEfHdxvfdbud+nZXvur5d3fteq1q722jjZeyjekEQ/C8PXePC4yo+K67z2+3bkDvdffl"
    "dkvk/lLTv3/B6Lq7B+5ui9+2G98duC93RE1fdjDSl52WyyP9shu3wvW0UXKv29rvcjfbKNnaf9nGG3+lTVKWwNowxY4w7R+8cdDz"
    "XTv0Ap+LcbbWuIM8BO+mHd6HkTcsT307dEdhOZ1xSPvFjPePQfvHtKc+fwgnbtuz33mjwdiO35tPFk9ezFvju3LofwEoNlqAPS9A"
    "k3eLJ4T/bGp8DuDDdm9UF0/4tQU47QXj6ahTZshrzNygROBmNfV3wIbVpI41sDuN2vbkbqtW2dk1xNd4aLxKWpX+0O15jQBbA7ix"
    "R7/YiaWX1erkztip0183MmoH3xvlA7zYeTipWja20ggDDFDS2K9+b9kEyW6QVCf6QNBpGTXUohfAe77Ay2rH69kPFcsMBZPqNdxp"
    "NLZ3dqj3+JM8LZ5UbgN3gsm9EwShUdvdw4iaarYNKtmcuB1CEuXWYNy+adQOULqOP3H6wAPwo45SbQ+1e6NZKXS7Xhl9crECIFGc"
    "w0bFlhUXAvruP1CKs4hiAIWa3a/b/W17osFCZTqZ6+s9nViLSmeUSuuMkDacptIIR6DOJ5VoPJmrPdAdeHdN+lOmSWnQnyZQbG9U"
    "9gHwYaONKfaC5p+mYeR378uSrjYYisstL7r1vFGzh5K1Os3QTjyPgLEoGg8bNTHlLaxYJ91qQTOqouYQFYjFqarCRr82Z6jeJ6g+"
    "YKiup6Ba1m41B16E2srUSdpcQGHesBl5d1GZAac7DoaN6QSUve2GXlz/ZJ5sGgCVXjNt3PQm48nMNVSlhuT4McuNbR57u+9PwpUz"
    "TuMm4MpPiSwel/ZHtEPKqyaQKhL4pEHDCMegmHIwTFhicGwABo0agT4PfHfpwHPD3MUwMygH1SY7UJEeu7Zn10ET9gF3lTBoP2YY"
    "u6l+Vdfq115Rv6jpzlxA0z4q7Xu8C/fjaSoTspmGaOh7fQypXYMqKuObee4zNl+T8Xjf7YxvgTyqxl7cVd6ZKNhyO/mS2KLLS9L+"
    "fdKaYgeNBFTurb84+5lJINqeWhwNey4DFFEmBSe0LdvTADxoYzL2eZmWbynR9Uaf+Kb80GNuA4NsdMftaVie+aEPhmsO1pC5oXph"
    "h+TX8rjbBa6kTITPWsyxPRalya1iEIJaNg2ghVYeJBTvk0wQg2etGPk1k/WrfxMQUycWapQVv4NZknCr55Jbe8kyF9ABVaEXBEX1"
    "MXhmNjSxeS/BStYOwObtpxEiQ6ys0yAS8zDG20vmi6kp0d1MHYbcA9n5aBb1mNLVigDzGgdy8gU/UKtWdhkdI18WDzGRb3b9AVai"
    "0QnGE7krS7Qrd5NdiRYsUUOlRSLY3B2BbSLBo8HvRi00wChOwlLd/tN0OCmPxiPPMvxRl4RO7Iu/uvHuWRzByLgC4Jz5mJY+um+A"
    "nC0InonPiXtIL036UwbwIiXyylIkagTexHMjQrMgl8RUYGm6AdgNJqOC7obbcy4syhDdHhnbQEo7+eQdJO/lk/eQfJBPPkByrZ5P"
    "r9WJZI0HBavf8SFk8WSJAnE/M+SeBaT5ZBz6nBnSJKZ45ungmGUTawcanygELEt/s6xVJFHbyMQl1vbkn6J+NRotD9jOs9Wr2wXQ"
    "zBVjtLHRjDvuttAQNltTspm1hPjw80rcGwPFwW626TmxFmWqgbdNuaZRMq692ozlCUZDWudFb2U6lxRF9Eq41rgOaiyuoNKH5Jva"
    "ezn5b2eXtsik/yCztwZPWc1jVCJDaVzCrRn9+nwpol3OGB6sYAzzRFS0VAmnLY1VZLTyrcwib/dw1osnS2AiCTBVMCQSYFgmIWpK"
    "Go+GpJYLKuz15kBcgwahmmYYBeMbT8k11QSK6geUGdqTFZl5DgToyk8dF3gwCNx7o1YBamtPW34bK/TF94JSpW5XQAfA41m2yG5U"
    "9sJVSBTcAxGjU5oZmssv1bkoKKfpSy09bXhfVL7UMpnqmUx1ylTPZNrOZNqmTNuZTDuZTDuUaSeTaTeTiaE7uknnksQ3PaELZKsM"
    "3T+lswpWOZ2zskN1yqXRQSbmf/cLQAxlRp3BPIbcstAOEtgwX0+bR1vSOB/Wsp5dy20bncDexWKKao3JeHDfI+4z6RMpFvC1T+Cf"
    "pAr82kwNUqCw1CCJLPRG02Eiw+3USYbL7xzej4wvFKbI7JxypVqnrVPpDdzWN+z6en3Vrs83rwl0B0xUey2/p+kPtg9y6gOivK1g"
    "fJtGgqsx3rcIO1rX9rhrUXfyCNZhu4hz0NgyqlcyEqjY6Piz+VpkdE/jvlbIlY+YHNkxwpcTwN5jBUnVsbresf3155pkqtzIdXzW"
    "vO2jYS7hAbsquoSuVt5+eP9DVmGTY613SFDGKuxBk1Y9sFTZix8/fLqcP4ovTwr/4eT80haP74s0QeITdO4F7PVSmUcVIw1uqhwl"
    "sHqp3aHtkWzzavE2z7WZm3Sxybm6CqheQWvyYwcK/eIBBuPeXFJQAuvcsATYyq3LCESARDPHfcraDH+e5+8kw8ScUlPxXIVzyNh1"
    "HHnzvPZEk1RqxFI0GbAVv1jZJTaQTsI0hLcjVLt5zW6aZxIbmMoarmzYH/Whwo4EsuvQ0YeQYpgvSDOPBO8dPHpqq8cakaA9+AY+"
    "SEjsQb2AwVeDrS5dqoUoW7gK6emXOSud2VosOi8hKYCYt64zMyx4ZHqWdHpZt1jH1B1kEK/UZfInoxLkv+7GHwfzR6LCGIc9Qlup"
    "2jJa88LjgvKtmH7ga2S9ma1DR0A1DPzjPlVZZuKiTCl+/yEpLE6AVi0A0xxBEp0hubRYE45zw/yy0Ojx4bFj0KlPC4wEdSCRYlTX"
    "9x/RddmJxsANozK0wIPOPC/XUSYe4KOV1+so4wW/o9qIBVBtK4mtsZeItoV4tm2x0Mb4RVYoObddeUa1kg9kGXXBJxdQmc7/Um1d"
    "XWrr4hqN/rZ2tlD7ZjVdBvEe6E1MB/EZTtyTKpA81pYPxwXuLUISOmlgLWxm9yZtDIAX9fMpVq4UkbI4f9GSriRwIEQYuFj13WTV"
    "d4tWXRI80di3aS7TxWmdivCa668Ai8yhh776XO5bFz+91gT234DxCk98RLfEedTydceY8iwCHRcRk7CuMjyFqRK9V3ZoC1kvlB/3"
    "mghXX1vRIlg5UcVouJr9qevtTe4SPFGvFovBA6/nZU8XY91iZvCPYljU+ZFoAFxHod5Ycgc7yW6g1YKuBsY7OEsXKGzodwDAamYD"
    "hSoXT2BvMnPD5QqgaDxt98uuUJwCCZfvF0++Y/MWxdnukKhPvWyrlLpMIeVQkaS0cqeIckrzLrNW0xrGJXssv6zZo8ZU5QWUTSow"
    "U9mu3AA4HNZSYeh1nI0omHobn1edKhVp7kiCjebavCaYaOBOQq+hHljWjWB9pDHaawmJtQxBEFQ2S8VSM5IcPa3iBerWqsNr0dlG"
    "1w/UXNoiraOnzbV+EDZXBTs631C8IZaOYH/tEVhxc6k+FVsnoCa/95cqMZaojheq/vV1GeJsL1U2HLqaCkIeHqlpfPmt+uDaaiMF"
    "2XZrOfZV6BCnLI85e2MlT1XoVoT2dr2ju0LS1W3NC7Z8t/W77GHUU4nWPguU+ddsWVdwoFgvr7HJt8Ln+5T5wTZyOp6abCfIK3cK"
    "z2K5nWC9dnR1ELXjjybT6IpMbJ0Qp2btfsHwpRZ3NQu1wsqsvkpei+1MJPrdFlAR3c7jEw0+3yCVqpIi6tXVZiwYF5toQsPuj+bL"
    "kLlOSJPDvBprbNEDKkuYPuZ4wbK1b+6VKqFwkjAPXzD6DqSZWoGy+JFEo3qwnGoUaafVlL6UisyMRUZeC7kWfUmmIk1HROJDhEQW"
    "FcCJ3kSf50WbV1Y218kHDWHJHC4HqzXoTdFEFDJkgKKANmFqGkVi3nolZ/NYpdMgygtuZbASm2mWPmznZwhdY9VIzRFXBeAL5g/k"
    "F/iNs7cHYyADWiUoFkv6UlmJZQEkg4iYd03Q2S4kHpRrtIy0ZUFaKBvz0KsRFsnLQ4G4infOqA9STHKhnRbzE2Ehb0vkSR1ZhJpq"
    "ZH85bdZPB3aL0I6u6ZcVV6Z5I0xO7+QNMTn9S6HkOrotHESxvYROcTkHHASCiEe8zdOmTqTq24xtU3sgANPSzG/e0a1kZ1KrDLXy"
    "9uqVlqKRZtDSnc67wXi4kuzVcTqRLtQpLqTTMFEo6lTQQmJw050alZfhgpI7enKHk4Fuesrmr5pAFx1GNNPQnTm3w+r68Ft4BP9J"
    "5cp0IKr40D2yN05YUWEE2u/NM+xoVabH+odHiBp7j6MaRfI8DVPn1ZqJpFd8SpKj/hlgeqQVaTXbXdZ/pS1uqI+rue3aEpUAlZQI"
    "XJkUFtrZ0Gku2vQfsd47y+QNrmtecH6cGlNvaCQH4ULjUa+mufHyjqzMSI64Rc4DcTJUqF2h7G3NXHQJsnuM2FEg0BcdLYUQOB4L"
    "wQffAsHCPosNZckMbxass2y7hNZTS8ZnkitUcA+dQ6TnYDfHhpEuBgePWd1ugfpX43i3GWenGGJRD2l11xkmzfvuQXas8TB1Znyt"
    "E4j0LGQPGlcoy9BlcrsqpHfodXSf/7LuyQ8DF3ZRFx5Y2Nq6BJs+P/p2q6xtAGZar7oPqiD0F5X+YL7StDpv3yxOy6Nuqly7yFq+"
    "VrNrB9s2UT55it92g85fRInwUyLZx94mImgVmIe2YyUIT1iB0Pew1eV3Va+2XWvjF9465C6WZtdITZEysMwfcrBwmBFlNKwpt2is"
    "SSeuhzsPWBv1CuwRdZaD7BEpa9iHZLLEdlFxGmzchbzkIbPMwjhjs89KmJwRZG1b1kRyweNt2lGyv86604JnUBsL0vGcFh8vzCRn"
    "tKOprHd2Cv0hUp3AE44w8piS5Yn95fsNjn1dMShS/qdUWEUSxSLOKUh/MbbQDkZ0I3IF16gg6j1WDSYNxOGv0fMea2L0jYeSy7RZ"
    "cg1evtQ2D4lsL9PWS8VoLgOjjDVzMFrftYqtlqLHWFg90N3EvWj/gaNpAhJ9or7zDnZfVttqMTvBPHcgrL4oiDpYBlHFtkVx8SIO"
    "89EkKuf2FUatx8AQybnqzBBYoyvQ3ANWZ+nZz5J5YSwdT/567idslUydJ3+nR5mtvaSdi3KEovLGWnmrtR3yD3tp777Uynp3k0K+"
    "ISo84M0pZHaz+0ecgCviQyVJ8dF8UKnDDQKF1L7VBET3aJTqTlljRidRq2f3cF7YFpSiiFVh5Ur0wJnAA2rd5UC0rYBI35fV3ep+"
    "tZUXB4tUm6J7y633ouW2e3K66o+1I9IpgjTZTSsUl3hDF7Gyqg8FJlOL5GMlj5pS1i4RDNHmq+wkBLudXobt9Che6rJBH6pLbyRr"
    "1k6lBeaKreiK3BkLSMy2VJbRDvt9gP1R8JaFrwJmeC97GredxmsPb6B4QWmU8Wp+d9Bt74HqFFgahe3hOgxYmveq1R+QK1PbaL/q"
    "1qor0VVdjlX0B6Z7o7y12k4KvIWz//Za4K3qLAJuiC23eU3GAqkGeass8U9JwaHIvEx3s7+mkCYwn64bUQzyZP4ts0nsIRXWlZ57"
    "f4nH954gl6ixEps9Ex+yXciHSBWAUObHfakMZho92CkqGI9CyL8o1v0dNutBkTNVFPQew7fsPaQwf4hJqa5iUoRAwJ16ND9yQEga"
    "5UbjeREu6LWi+OCwoG/7sdNzltCtZcP2HYV7qe8WKjlzmtClPixy+N9FrcF7MhtX6yIoy18NPeBzo6SFsqjRyaY1h9+nDSdP/MNE"
    "FLlvwk1TKj6TwhwGY1FU7f6eqDW6Tfcg1y+581MBG6SgRrJV2m5pm9DlgiyNlxoXL9IexbqgV10oU5GVpslqmCsVJ1kPWm0ScNje"
    "hUVEOfA607bXAWKQtpT0as1faEcPNCVP/SHFknLhc635XqW/oPbDLRkQ6XBLRreilcYPzFKMNsyiQoSuwnZE6CTD4ABYmAOZjpng"
    "ZHzQcvOUy3R8AZY2ROyrjZ0qwkvxjItnimP0anznbJBouEP/bRh8dCvYCmlWcHQoPcAMVsigBQQS2ja29+zarkGP+wZY5t0Ng/RN"
    "zgaNcMMQHl/OhgwUpBLKsie1yt7G1pKK6wdJxRQ4Iq45r1s5sB5uidrZwiTEE4KpOjrs17IRvZByODl6R1pmqFIoHpRn/D//h4FV"
    "hlGsMZwOIr+cxJDClxmF/sExMgWSwqsePAqamHAKR4rx4dYErVOLYpm0R23FOCyItmK0LbVPG4YPE4/huOOd0tvR6Yf3788uLs4/"
    "vD/789/9Txgc8j9QGB4aouxaubuj3iNyt2mnbxyVyw3+Ty8Tj1cAtxccPXmSAVaxqcmkV9QmEjBIiocWhtgzngH6PFbhuHjEXCvV"
    "xJYEsira12o7hOK4VH1icw0DXuqyx6RN/UhpGzpUxLn7GHm/fnThUVwyH9GOYCvt8xoDa4yNKR9GdXx48/fIAAerjNyp2YFjsNbU"
    "Bd7UXGogkAECyqkV2kgDjhwRDztTcIyh7WjgUzB2Ue/kB4qcFucsHvVJSEYGPOZVA+stHVS6WvKQRD5K4WLvsGJqaKl8OAiTNb/H"
    "0xEBUi4PjsBknrd4ivPEDaebZr/LjXT/O2j84uztW6P053/9b8G2WmoEeqYpQP/VT380Spt6DtGd5SOFX6ToHD1k1jlZvlWLtHph"
    "LjXgK4A8anl2gTiB3spl4WxA+oQnQXcwI0Uq+I1c2YnqDjmtxYUzhoMbRx96I98IeePARt81fMDmdMynQIbAnB4iOiLNBVLHBgfW"
    "NDqmGo5Rqu0OG8D9pMqmDVfrNwyI6PJtB28v+ZtVMT4MokDU1QZmGX1xbQNIwqMWQam/fBlT8z3/n/8DgvPhOMGY+P/8f9GmBV3Z"
    "NT4ZHSAVkyIMuhFKjmgpxiMQRKAbTg28BndeDmWGdtwBZndcIZxevK4JYvqGHbp68cFbIT6cZzx3h5MmejWiGR1FmfUfvSJ99Trb"
    "ktCxgNbRj/SY30upnQQHP5n7ImhvFFZcABF1BqQUtofHXme2oTob5Kpabwe/P/vh5PL85w+pzct1/uyiozLncJrMRHZ7f/xwca7X"
    "kN/cv8uefTOYgobJVWNhwWiNxzdi2ZbPd1fONge1XI1L/jPC3BnKTL8wBcb5NdhVlHFXkATvbk2aAKcvVcJ7EFPqGFb4KiXMgkjY"
    "WE5U2X9G5BWPBdzYKo7hoJBBYIcUffJS03Ev6Vj74l7SsTwIjlSe90CJWT4rUyGd40MHIQt8vMsANaee9gsq0TeS11O06YIegzHt"
    "VRJQJ5LlB2mlWK2XisPNovg4LhMaEs4YBtsRb4iXDSDUyC3PwHDvyhrTxslHwOyHWyLzAzXsVbM1dN1BSFX016yhvrOsih2tijTc"
    "LYEg4fCTmQ0Vo02ipqNDX30vtACwaHH8o7N3JyBt+uKtKgjLgKTY7trFSK0rywnitnbBkSx3gV1lvEWM4XVLQv0iSl5+rBlbxuXH"
    "ehHIEzb+87//3//87/9vo+0OW/5Y0dZCxlj4QgngJk1BGkp/CFxIXmMDUaAh63oDCg48MjBRtjEjed63jU8X58RqwMlxABa+48Wk"
    "nLoqal/CWhdjgp2VosL5qOOT3Bj4BgmVsZy4AltiJy4VC9iePeErETf5MGLtwGEUyMJ9TkM5+oN/td13yfOP8eOOfNyKAs4rKiEV"
    "g6yH6t7iBPqldovGiTnZODoBx4XxuTQwPC3dMjczhd0BgKvFmOK53ls512+hM4NwTWI3LetQSOwrZtr1l890hq0V2S/R83jHa4qr"
    "7Vwshr1dqnfyO47uUlcjsBaieGRHoZROEclpStHBeQv4gvf1WTkBLrvdJhl65i8VPhkIqMlvWSfI0yvlZxlAW+hO9HUqZnqEx5Hk"
    "fORLijMsxPmqdEuifwRCB2tfTIMuUcaPCcD6VRtRUjkp3YppC8UsxyJ0B1OII55Ret6LmgeIffwtDfaSBlvT+yUNXkDvbEBQ/ZYG"
    "gqQB2BgMVrVA8vJfOIYR/GqWNPEe0dsN4XYz8/7CkQDcequawWf3G5vRoGtEUfgLGznBJ+xJzwggpM8giucbWo/riPdCmgnTDMY3"
    "HmD0uqeDcAWfd0rZvTW2l2KpVu4pEFpJrvw1ObR2sAyoTwN/QmhirWrC6GbZUpDgsnZvlq7oOywiLiEAWvWHD60mXtnBjuf/tw3Z"
    "lnC02zDYZK4PbtALMP2EDA1agggKzczSJN+WyhjTFrCqlAhG0VJe/UEz2JyK9yHiKI95No7eunQxAjAHeLAxzlLo7o1//p/B/YxC"
    "TCpzQXQdQjD0oaMJen2/gdmGAhV9Q8PGNHQJZihLB7pUTymNYm3rb1Mkwf/JTelbdGGQFAMpRmkoVIsZTikrq0V9sew3UlSTU5dx"
    "YSAFNJROWwarQ2N2SvLUKXlYfrqMVVxx0lvgAKIIuOBi4DMrLj7EHQBUtTGXH4W+CiOfMr1XNbpQshOrNc4VJDLDOvKuz7qvuMzP"
    "4lYMaL1i7jpmEIcYTq2PPyQEydS0Ximm0dnm+nXwvz/DxKSulQW7Hz9rQgPeYmhawnXSU57vfDwDspopvwT0jSWrWshC4Rz2i2uI"
    "472JOlbzHlLU8yniEvTbG6YVXu1RgtBibTYrsE+D+9Vq8BHnWK0GH6TzrNDCF/RLYch0vy6imwf6xTke6Fc6z+P6BZRbUfg2M2d0"
    "b87qORsPH56zVJ7H9e0NkLncKz/gTppOtodvRr0Hesg5HuhhOs9aDAMLaOrAilXdAO7IL2b4x5PJ0uOlb95t79zJxCUFOxxr6cSU"
    "MUVWzRl3ASgh+t278Mnr+XT6a3gzUpCvFpxwVxDxnLY6x+17kCgL9/50ECuDxpK7ogfkmg5+T3npDaMjzKBEwwYV4iPH5ULTEvXU"
    "4xRTCkM9UjGlEMiaxbZlsQxLVTDhyzRBg/aFR9yOGns7zTi9KUTnySyu0PzQC7EP/CRcigQXjceNo3McKU1h5tTrQWsFbqflj1yh"
    "bYKWyTbenZy+to1XCDSAcywU9KQSCvK3AaprE9H1QHRhQgKQgz3Y1k51axuX5IiNOhIk2NbOB5C9i5mjq6loIMTi8BLh1Es/X0Ma"
    "2ZEUHbKBCYvEcRo3P0bzFmqdjpadYTeg2AlDgrrfpmrCcidqYPD4RA06IFyAhu/xERqfoBH/RyPSWJ6KcZ4couH7GOMhEWzM6op2"
    "zMAYf/43/9HYg38S3/zFjB8qh/RslDAzlHdgQuHDzCHO60KSS0M+/ovNMKgHwk4Ac4IDwvcYFsarNd6D6mpEHW8YvSnO2HnmdLsN"
    "FBLDoBFMB9wxHFO6oy8+ARpYUQEbZK0jzg4OQ16ZoyelkuUczZ+YU/QKOMhvR2bzCVUTGc+c0DnC1XZTOrGrYHqD+wvwwW2oC0uh"
    "pXIBWocTp3Rnu3YLVWGX9CtkiOTa4hEOXC2brhCS+bvD6L1TGtkdp47sI5hFvR3TPXYXaHzUK5l+VD6/NO05cSvD6fBNIAJHvUZk"
    "6ChsdGzUXZS+SBqYOBPniJopTezJkYOz8ON6gx6Ot+mnUjveaezF2Sdt5845Kt0dOdVjc9NsmKa1yYXvXqCkXbc2ze/jKQl7MrPI"
    "e3eIXxzIi1I8XkScK/ED45CSNnASN9BnZ+YczdAZ7+UxNzPbwiM388ps8Ie95MMef3gnP2wnHxDuGh/+xmyIFLuajMft1J2RcyTn"
    "E0fOSLkgTwwYiZlVM87Y7w+HToTFF68dB/fRGa+B5EoRjRw1Bh4UliOusdSp9LzoxzE83EqWRdO0mSS/80cwLaUPC71y4Lp1qqes"
    "pShb5wXdLNhJ1dnp9PuP7DB/pf5upfoLObJfsjZpCg39QzK+vhk3ywPBTpiHTgzcVQHcOOfkvZBuWf+0tVfVpyv8Hu9xzV7Yporl"
    "SoWOM5oOBsem2QgthEBiwbu0dfX88Gjj81bPbgPw5uZz1MWMnGmbh/Q8iOjxiB57/LhBj79Nx3hZXLU/JwB4+vbCmUOB0Zgz4cHt"
    "cYycTVvYgZqCtpoLBMO/ifMIYqnladeRA7Ac50jRRT3jtrmIh3r++hdergsvKl2ZFx9/QUffv6a/r0/o75vLd+evzM9xXyHle/cO"
    "kMgESKKE0pW+G5ZcCt5n0QyZz2ibTkqTuMSb9z84c/MMunvcZWgQw4tcH13SuJO5hjd0qRktmXrgTYFGB0iRT+i/yQwykk5mQiJF"
    "kqo1+ymuGeN8AlWC8ZqX0IYnpFPFZXwD8QrcGnxEWB6HlTM2nWUOHLO2i8miMyIAqSsy8uuP5CXhlGu2vFoTWh1RjmLNnQWBY8bo"
    "qHWPs1qHMbicNme+aJZeP3/+usKKmPDr16vPVgU89RmE8pLrHA2veBI/O24MtEP0njr/7uQjFVeozu996Doogfx+T6US0p15lPz0"
    "aYm/PH/OPxW66tNzHMc8OYWBwpn5/PlT8WHmRWOvE6+T1+2S/E9VMOlALURON0vp6lw/eaq4HTIOt75+BfNRtV++jCuDx98Fj582"
    "Osykb0vWFqGCzTHdlyjy0AL5Ix4Jd77kWseiZrhqIUBJWKZaShasmGWJn0/enr8W1dJMMrXvHauHCt/g2ajD2FsViLq+cwM41bIn"
    "T3DZwPU541zC1c1njEjuoptNc4hLGsnDVz2z271p2klzWBuwV4JDJ/7lns2mMB5xlSevmiOWy++WnsbDtcRCz28aJlm5mjZiZCya"
    "cZnACTNTQd9QQ3DoVLWyIk8nKY4sYSUc+JOjUqlg3GSnjBHCmUPvAaWiCq4gSR3fiLRFMsIwYqsgGp5Cl05q1LILXli5IbhDFbKZ"
    "67TwFLWM8Y1UmuL92Zx3wALHuv/jv8IhweVPH8WKK6Oa60zF3OOlVdPXwsr/+//w//6f/2Ccvb/8dHJ5Ypy/Nz6dX558ev2BLMIk"
    "X8pMqWtsPpszGZcbCRMKsr8wPun9WdY8FqWw9b//H4zLs3cfPxg/XZ6/PTMuTk9e/3QZj3CRASQY1hWBke07gFUsctQdWnbR/Ktt"
    "iK1/hWxwPrI5+68c1OkI4OGP2t7z50naYQJt1vE1NIVTMjk2ns194eAOhvAnCppxiqAZJczCszkzCEkF1uIa2+KzjPRXejXGWYEL"
    "NudPUHyWTJpd09JnTNe9ClMaPaWmRM4//8P/lpqx8/c/fIK18oeGEvVasUKlEz2bAzhoexybBvn/mQ163woFbjiEZzI+wAiKGMNF"
    "0fo8mxNbQSCGi2Sgn1eSZKpvddW3N8rkUJNQGjj4OIonh6cZs/Xnv/t3yYypaeYGjBJ1ul2itbIWhfajMGu7kEaJjcMWVKBaA6m6"
    "0tJveobZOM5P5qoIPJWwLXwzns0FIdCnEGi+ZhFXt/heSN8ppVLafFUsqlhEAvvzd2dvPp28OzNgcH5x/sPb85NLbRWPCNIY6S5o"
    "SgB11BeaELUI14SGBGBToAjPAefVPnIOdo+vzJNNsAOn6rAUUjudHTFrASsDn57H5ucG5a5SbpHuGkkJpLwbDyCuwipTZt2nrK/w"
    "4dV0PMrkPRG5rszTTLuwqif5laqD4gB5NNowGd96wQ+lmbah23fOXtVu3zu7B3bgwMloEjmlILA7IHJXpfbdZhC8YL61PQ5LHfH4"
    "8XwLzjiWhR35xr/zOiXck1Rq38dZAXMrsn5O0MOk6kyiUmBTFntSi182Zy9qlQMkeSJpG8yxPerwSxm+EkmWFAaEY0jKAwROi8be"
    "3hIXEJeOA5yNd8/mk+pV9TPhEzzUPi9Ons0DesMfroQ+eCqHRzmKPUN0d6ms08bLOIG+t90J9hSJgewz8qie1FSO2kM9EfqwR3SE"
    "Uoy7Gm3H9h2qvheP93i8q9PjqEON44N64x6kWyU3smyj2ysabfswxfUIDFWzgEXVLA4WY2cZPZjnWkOtx44yOlUjV4RCivYW5Adh"
    "6Y6qttd2JC+KjGlK13N445e8Nm6EHk9QFH/t/tRzhAhSIUb9FFvwJCpVrRfb+5siGZqXXtR/sbttfQ9YTjZAB4L2eHKcpt4iSAeR"
    "Aij+SrVtm0AWKPz1+cm7k/eXZ1h9T6Ad88OnDwZbZex+L+U8aJjMhaLmDZIIVFuu/2HkgP33f/VGdDzVIeLr+kmGwcwpte2BPbMn"
    "7WiG/Z8ikYNZjJ0T90Cs08KingqcSeUWVgMdZDENUtqM6ILEnclOJW1bOznnDNso8fbYpJA3GAZTe3PxjC4DBLXEX6aWkkiA8YL8"
    "hHT8TVFRfNIICU7gOJIpMMFGmi7giDZjge0mQ9O0vP1wgCFhbRfG7u73uNPrex4pkUpuBHvBUjOdamBE5ywtPasgjtS5EZSZTx2H"
    "U2nZyVX3qKSy0ldBgjmd1m+RImk9hoqhmpvUKDi2ycbRv/zTP/5H0jnKnvEULaWRHaLJMf/CizCl2e6MTOZF8E53PCGFr2syBZEX"
    "vfuXf/pv/61kKcCwxJyG6nyqzWfzhGlf4E3jLReZxckcUg1GioRj+gDBx+ZFm05jzk+oU/woPNrMBTE+eRCNDwZo1yy+17kU/pvQ"
    "Tsk4US4C5t5V/bOi/lp+mGp2xjJrj5Ex563JvMZXg07JZYYQO39Gme7Af6lXZL3LVSvPonkM8XJAAsZBNSsgU8syIWChTw9xXZNb"
    "zi7IPpDWQq7dxw+XZ+//9qRhqEkpWLP0spAHkCz76exv//ZDLL+U3p18+puzyxhoU+4RPgOsQgZgFmndFUoAHAxmJZMsdcGtXLyF"
    "aAsZB8inVKaHX4FNoORTmTABtokTesoVTWqUjRH2ixK/b8nKyzUrX6guCtUzherpQoXj7mZwBbyuDVpIkmh+Hd8ck3RJ0rNYGC39"
    "X/7pv/lf8eXP/93fm0SvaYOLr1+/Qie8iNnOFUZa5MZdjN04LepSElOmBe37f/evDWVHvExoytqKH25JVJyikfBv71CRgNSsCaUc"
    "OEp5pEQsoUiwKhQZuQRN/z2IhiKd91ZZPbKu2zCelczvlPugCY4QBiqnwqXfGUgKeXyNlZPPi9iCRp2xsMsiTjVwgBEJu+TkvEXR"
    "urgRtOCTteaPl+/eon4Iz1CaQm2/Y0FROylRHiUamlBGmCl/DgrlRyZ2qQOX5KgHd4o1jMSFE7ZNE9jwujiNchODyfgIiI7N6Jwq"
    "Oc1yBxxvjn2vaB3MtH7Diy67xKQLfaDUAs9wrVHhkcvJYIAxsx+EvFXCTBR7OJS4Q6S26CRCLfjqlUzdLMy07yoES8hRmYGycot0"
    "EfSTrRdGOf4fDprgZxnqKS+2pCT0t2+dK/NnQIzPJ/SkKOW3RIvqsYQynLBmVTzIrJ+VnuwLMASffxzWq8fVxuxwp3pcw88endDM"
    "DiEzbTd24sxA7s4XsCfy3tJn8y+btYV1rQk6wxv2DC31x2FkAwulBR46vgGXST+Bs3+QEnlWSjz2SiFHE2xgIcdVulXbrSVa2AlL"
    "MJRs2b+p55rSt16TBABiEctKddZyTEAw9CSSCoRYoMkFv+XL/ZYpd82aNdLnhqQpxgqU6MV3qk3/cLfpb25a4aZzLeQRhYHoqhJM"
    "sE84hxFQ0JYimv9ie28ToRX5peTjzAQJ5RoFGgTjzexeuglnp8qNxKc0opYdVDF0/O9rVcAfpoum5eUOFsNu0ePw+GC3gSCGdOkq"
    "9Y6FFIWLb0BbwAniJlrJCQrpxdUnA9cEKFHG1WeE04Vc08rnl+mZ/FuEJlkFSDB1dVW1TYijVfOzfVXfxfMuP+5W6TgND/tI2xRp"
    "BGvmJuf9HG/O0tXMjj5nwGOvrou3PGbClPGYYbXKstIk32mRnB2jMAQctUEOYE/BoeGxmOMhHQMjDIe8JSn+BCoWgU5QKYyWEXce"
    "LKCKMb7A+ZwS3zK2hp9UtZoFEnimvqy8tBK9TvbyZbpZD8UkvHA7vZiN7gwSY8Y4ykgwZiUjRee0CiI5vNwniGT7ULROP3WRwMJg"
    "L5E3pdcouVSQ7MmdJ8mTHzBR+6pThEI0SiLUDPH2mPUyUSfqHHGnriyV/WEv448W20Ayv7CQEmqCOjC1DreZPlc3+Yprk9UghZ8x"
    "Xbp60wA2nc8coUCbkdaMzkElAnUI3xJFQZVCzVURK/NaLYwDQjxb0Cxei0wpEsLDBzIXcGBufrGao46sKF4q51qu1bN5aYatYRFE"
    "L2jdrtUB05eFplEjR3pHIW4i45yCEbP4a5OBYfozEkwLH2Cbl/6ABP4AWpMpMR7yB9ijpT8gwSQmRafBP5S6Ixt2bmcDHLC1zkgu"
    "5jVUCOyL0x3RHHKWFDejHfPH38XksFjiEAErYc642jQfRA18/fq3b6++fJafCwpqvAIZQ/xQytC3XSZvO6TQ2/59qdtK6pEichqN"
    "ULQuQykkctPVXxmUZuTRWYFK7Ld8qd9ySDCvJlNqov2Y3RZ0TuJ4nUiVehw3YQt7+wVhtRENZ7tONCmjflSG21msQBhpt1gTyUgg"
    "Vr3tVgWx2jmIlW5LiNMoN8aHFXHAheup4nYlNqRuABluV75dDQeOIFHEJdsdqi2nFH6xWwPqKOmatPnDR1Bf+gLqzr+Svss6MWdf"
    "FknoH/mawcP4b73oP6RQNhAjGdF58PTSqNv76dGyC+rWsoI7ccG9pGAS2kf+o8NOfR4yDLY0CixisE/p7F2TzdwOxx4j0Uzu+NCB"
    "iQox1kDOsOgBvijFooJ6OBt49GPxzhXlboxx98pkEZklcDbysE2abf4Lqdmk0HD4IWCRP5TKy4/fNr3AnMM2Wz2qxXdhqXGK82un"
    "HZLZzMeAZKboHkb8U4/kcXPzxiIheFiy0gLPFBLZLGYNJ4ET24jdQo03vkUwzRkEuI+A9sEnikn19WsNZ6HAcO0ZtfRqLMwLTwcU"
    "vvsTiGLJsm8Tu5yaNMwRWDmoMCCBFPSXZxHQZanTZLTDhaC9u32BHn79ihSRB0l9SkL/ZSaRpRnnEN8TvNKO7mTHGfPfRSWz3gH5"
    "RjqR2ktFQ0soBdoN9lf8ihzYpW7AY6RPt3ZfSRBzfKX3hTa5kY+p5WTI5zatYCioBSoivxnYm1Bwu42/xiQGILih8Y6c821yp+FI"
    "e6bkGiJtOiuVCtfEovQAp2CobOi5OLD1yNe0NLDUDG9iY2E+RG6pBq+BKFQVOWndOXebtR0yTGjdbUa3R7flHYsSy7WdcnTbxGPc"
    "7I7dulNMTOteT78Xh840Juw/3gPOaYXhVEwq4ySVTpDOydStP/CC1ZqqME9s685u3dvRLfpuaRXIb5vgKVv39FfmKGgbG4gL0uqe"
    "kBsO7AXgh2PGia8U520KzttsikmKpYOB7VtiaqleMa+YgM2X1HZtG9S1tkfgqVAqGwmdzhxWgdCzqXM0ncC9PaVUTaUTw4sjt6Co"
    "QTvAdx0Y/1yho59hg+TEVklyTzx1v3592u7zn0okf+QqY3/0SVv1lPX1/BZ1nyoVwzw7XYRomhpM1h+CyfTUiqiNZjM1W6+PTSix"
    "SB8Gs9ieUI3BOw205HxElrcwKmZPrQ6pk+B6nQrKZdq3W3W7v1VXmyvZvSNHG6f9PsFVkFNHFgx0nFH5vQ27vrfOHv18cvbr9Hvp"
    "HNju3SvwFLY7c33w+WVKLSPNnvzocNqLyt6OjahFDuhKINPKkx/LSLKDS4fyb05+3MSrdox669xSTW/pzye074EHu916b9/5ju8c"
    "0RfwXbivAxBrvaDPNk68nIzVU4MszdSuHIydc6jWRrhiy+77Tlm9aIxfGIHzGwnOD9njSRiMASqVwZVPIFPx6lX1tEtPVhPVxRu3"
    "79OX/rK8UtgOSYGTaUIYxORqo2Rog61ksSYdBx/Kg7H1AiFNm4Nx2Zl0UGyTfkSWe1I98cyWamXIKsi7JctYLyY/qjmZoQ2nWjwD"
    "/C3uCL3RMGY8YP5Gf0CzFKbIIR4B9dUHoF5TqtygKzdQqjRvEtZ75gzGm2q0N1tAi/e6MHIPccQCDBRgRL4omZJbcDkZfXTJDJbf"
    "hzA6vByXCIZQmxVjTaTdCnBTqaJCWaxwaz8CFab2Mcw5Z6Dm3NzmHjW4SGmXdEiUE0G4iqd/iyYei/gCN0tleoYcbeQ4oocxHo7N"
    "/KVedQvYIn9tF5LT9OLOL/lWmbbWi8p2zZbbtDzr2yINWp1ZX4NKHm0JojaZxdq3HVYCFUy/vkrImSFat53mqln4xeFu2X907qkp"
    "Bkafzk+jY21pf7H/aDW0ZaX3hb6gQm+IjyWxM+3TShtKqsqOuKW7JHauLciqSH9geUiBm5v908p00jitdEa27PfSCdCWMDclvMPE"
    "HlsCytqG+IV2g31fkjjISoF3cb5Bki8GeNGiYJIw1TEakCOz5VAtUmmqz8Biuc9pkPolAacogaKEXbVbZTofi0Gqx8bo4ZFTP4Du"
    "PDx0yngo12C9SssAhf/M6YXUaEinple4wKn2+amwLE8nNqoPLmAvVRXDVbfUA3WvPn9OP9Ta8+f+EYpC3E+DY2YJe3CZiJc+h4Kk"
    "0xTVflRVFRE8q6XYPGhmYFlfw1/Ku/YfN1+m0zZF2sKD7XS6RgaC8sM1lgtqRNpCjQx7Rsy3tuHJWITdo+1BBikPJoyV7enEGUzk"
    "fhhhHRStAG/2Fg2Rbq50tW1vf87vjOlkxRxm0figEI0PitB4qunPBXxuruEYfCW6rqPi8kvmgsqIqnuQJw+t3nLiIMjivrp7bR2G"
    "8GFagvlOiMngXgl4Iav02fybzoSBzyDPwsQf59x/JBW+4DhsxlB0Wi2T6CyapkAcTseJ9TixnlX5E8YfsNofrc6OBrAAnx32fQXd"
    "S2h2jNZSa1K3dz4vR5S9wbjlDk4Gk77rVA52f08Cr1ddWwYrWWiJEXi8rOImv0cw+ssYBxFJJLPYA2bCN4kPKuMEbJEA8Hrs1jcy"
    "LXmZRnXIpChetR1T9KsOjn5zT5O2AuZEA+ZDZ+SvYL0IfsxvOjN/scteliHh9QzuS/tkWXlLT3DQLIsEbvEKPA5o+X41Ac5ZfBKV"
    "hsHgv0jGMZ7UWZo1jBd5FS9VrAPACNfjpwImF0HofytPVaQxiHuU7Tidp6Fl0ATLTlomEmHZ29AA7SdTV1xz0UTqEnManMngLssA"
    "gMyKyXBqu1Zq9oWRArwhEKPQPCZXPOpgRBPTYBNx9WaLyeuTuLu5G6vVYs8mYhaeP0/eD0dq3n0nSV3KHApQrBeqddblBIltX80D"
    "cu+L2L9EzfaL4P737KvYDVFOgXBGXOrY2sF5qFmHthmOqyahIZjAJ+99uCDqn9m1MklYWPb1Bxx9dCeKr8RJiPFjnMKszeLavn4b"
    "Jw1kptM4pa0y/Yxgq7DtFI6pJSXJIi/hL+mUEm8AGORTGWGMB118T+cMyTVrcU2iPNRUQr0Er63OGQU0eIvgBohPjNNLeTMirYtp"
    "ezEaSqmcSN8U65qk101TOSqpqpepgtdU2dw6UjVc3ivv1xPEzFtAc98s4USOq/+lHFQIJZX3oDIgnQtx8YmzXskXUI29Yx37jXIN"
    "uiQc3IbRibpa4Q0ZBJVi5RyjrwfnCfpfmijh36e7Bq5VvVQXiuADcPycNUhjKF5x3MpXC6Or5PzHaZX2WktG6/May/O6QtGcswuU"
    "VLV8iURJtUipxditN2UN3D15rq1tz8IVmdy+YKxJzoH0u2J6qG6enTXGrE9/qlcrFyBuQUqK4x+coXJ13K1uDnE8vqfO6dNqWyq5"
    "Qmsb99iC77xwNeQVIBdPzGpHTqhEuKPD+v832lfzPFa6wmcUsR1gVeeLwKYUgIGCMwQiUlYbFog+xW4g7SvfkLBa/wo2MnSupL6B"
    "lRH4s42xDmGKpnyXYwdlM4m/A/Zc18ruSq0sTn7w+8qBEiOjSp30lY6WMiT44C7Wq/pbDGEvwGOl1IiSfZv0H8lyPqjhq+++uPkG"
    "vd6aJPH/Vz3fLKfjk9zobjU93N2qNl5d7NgpFId01mDluHerhQNXyQ+JxmrhQixceLgN+4ZNax2tXngVfs4sUsLH/DVwDjh+GrnZ"
    "7CSC5IRPh/xjrb93xF/dl4BZShNQ7BAqJcGFykEWfS9UZWWFtriDhZypYExFvR1mS2XlNuwGcuxpfnGSU7rs+GMN5EM8bYZ5fVhm"
    "YM60w6YVFuMEm/f5KxLHMqX53rzi4jzWSGkTtCoEqtVpwxGpxvQEnb3V04nBfYi//f34WaGo7hdBwVJoXh80fomhwo9hYicLEYti"
    "/nnHvpKz7PMc48hZVMNnzsAVIVmNwA5miHoXDcWVUnMghMR0WoLrzFhaCON2ikRUZGwx9Z15t2HSXRp2exDKp9/I3Z6M3BsmmXeb"
    "NlwIBIek3PwRnFRqX2twy5qarH+lR4oK8cVMMp4EuAFCy4oI4klmxBJnl4F/iAvAOhy3SjgYLnS+uqWoxgBRZJmZtUVnTuwcu1tV"
    "9nUzch25TmJYcRxNuvta+ddOFgUXacbhz68bWtlAXPL5UOE46vp1EjCCrAAv78BqiggQCJNxSVdVmPbZLx/PP529hiOP8EI37Qt4"
    "Ln3kFAqbdPrh7cdzSoZ//A9nlw1SsRmfTn744fyn90iOWxiFuD5HhKSAzBVWRuERe1rLSzHgKhR/OCzzF3nhBjkRvT/7CZ4s8YxT"
    "MI2PdxzvIu0K/5GgVXgO8tF3BbYtI8nmpj2xyBHL+MPJ+SVi/519OoWXsXH64/lPF8rLXnPKU2EZRKVJYAa5zrFTYrPIzZ/bKXDS"
    "kp5bAC3hpWPIzxSqXiTE3lwFNzlsHP2VUeizoyIEJGcdIbkQijAex6aIUwUHZrqJ5r9GcCvANX3n5X+axP84VvBwJb99Zon4Vjmp"
    "NGB7JE/nzeXDFtOLrWIAmM7evz5fMhZhzZwLbjDzQx8+kIKrlrsl591C8a/k6cPUh3gR0igIIVAEEvEq0iUUGByOpamV+Q3BToQL"
    "4Kb07kuPFVYi7cG0gxBJlNkqqCe89SOQe3zuAihQiClcQ2Zk/9MmJyOqdpKs4EiFShEwxPkoOPbKjIcyI4W41hrSNpb8juDT+e+8"
    "v0QGiisdZ3iKDUMJAtvLRDLIW1gp5xeBni/deHGU71G8YsnmuUEkoDnmtiGC0dwPbT5gEa/irIWc5MQ7PVHknC69JjvtmHQyOPHa"
    "TFx+F1eYbcL2wuQ15d0k9+WJg7bh12S/4od7JaOUyI9r3MV3QErI+h3z+ASXRJO+hyz0IPKUXlmNk/Ir6wVawXQvEt8oEr8L3aIQ"
    "jQrSkbkZQ2iczO+x4xOHn804PhG1dBPCAUmcEZyM9mN3cVYn4kt9/UpP6pSKYimV5PPRJDg2uyBqZhdGanCC5tA8wxZRl1qDpB/N"
    "X5oimcWzqzlJa5gutqMByDgCLI4LtjhdpY2oru8/vEMQlpN4f7OXofKYpbKJzykRrAIEmaEKAhtmKYJAiSAHAn8ySSFgyLYry1EI"
    "4GPptaveLQoXRS5jroyB6FIYPpKNzaSLTW0DXFNQZxVjY5l/s+YHHcSO0ER7ONyVwaFPOmu6QUedNIJsd8bRxpIIl8/miAt2xYju"
    "s7A/X1jF90+FG0eqxaVYWHdwjv1Vo47ok3QIlhR2oX8AKBXBRtRl1B575i/xdlxGErRyHOQjdpi/zl3xInK7D7ZyvU63BUjrfsEy"
    "MIvuGax89/O3zfzdPyoOImks8RbuLnRnW7l307Op3AVSiQReHGlgR7haUOw79hov2EoMimDNko2i4c3vFaiKDGbRQucnpt0ZrQiE"
    "I4J0EUu0epHWZDXABP3dP5pFa5b28u0yTF9xLDZzr4o/dLzxmbHpTYxNEaaPAAMGz0LfTRqom/gsxNz50Wzw6x691fCG+t4VMzUE"
    "ZhAiSmGbfbb8iHYkSTcLoVLn9CNOoKwsRnBiPJTEmzU370tjwqfCFrCvOCGzOF5ADsTWckhftdh0VR1nX+a7vXzTJhwpG/g9dp8U"
    "dqczkt1JPM7X6QAMDx/VPseN11eI/I0plDzNLWRoZIU3wfZG2v+4YNWEojX2TGbqT9dBBrjzElEx4VnskwMCGI9K0jCzBwlzm4T8"
    "S3ECivAzO7LS05hInRH1r0Qw/c+atzEUN3wOAKFUeRUT/Et2yiK/orwrMn0ybcEMUfhUN2x7fDpA8OXFL1aT7HUM0l94pO8orMYq"
    "5CZfsU2vzk622EhaXM1rKnXN0ziuojVvVXgp6DY72BYIL28vgIq7lfYFpEVW1wJRvN7ARUzl6ajntxCOGL7sIjIjUGLJ3CQSKBOA"
    "Yy3GkBXjZDYDn4BoEZP7qE/OEKK2yuSew0lgSbEsBh8qIAq026NQzQj024+iSWNrq1bfr1Tx/1rjAHxsHBcu0ZgnpzIq7uPTDBdZ"
    "PFif1bP6aAWcH71N3N6pRyT1+XRpGYyspSF1HO8bWnyjxMGWEf2Ktfy4hxqByX26IuM3XA1BMcpDjuc6tmLZOKvtp+vRnQLZjNnK"
    "dWMPEFCinlVDzqytjL5zIKPviMGTUoINggwZa6eRROX54fzk7dsPxtuTdx/PoKHgNKHoKMIo1JsNQXzDODjBgaXY9esV97ukWbyY"
    "9TKytJj57WMR+G5TMDFsmxQzMoJEy4gQ13n6wbI+W8mtByHJnLEAqyZN8cQ8eYTnZdRr3EebmOH72eAJId1m7tORMkncmOqkU/lQ"
    "FXTfuNjftK/VzeIpSSjZ3Qib9ObN2/P3Z2aDD8soO1HpDvAK6HRxEBni3MD+vj57x3EaX0N7ZFycv/vpLR5oo2I3FxdkbdpbcCNU"
    "TKmDPp2dvD3jYpoqKFKHd+BUpiGFAF0QQzFv+RHOTBvmq/NLKMFM+97tj8cN848nP36AaowINimx/nBh2rjnvGG+ef6Dabt+gzQw"
    "CyUZyvvSUzPyofUnzEcFAmxYGg2tLG+Dg2swNtwLClvLjIzrQ/eBTj7V40iRotRBFg5QXBlTRtozIjSKTGCAOAbokD7UTMtAKVEC"
    "t/Em3A9hTK4YkdIJu8Zwg1juhHywx3789OHj+emvJx/Pf/2bsz9Se0DTX7+WqF0ZnCVRJ1nEQyUxCMMOGTkMwoXQWLIu+eZzEUeV"
    "rFLX4TXCTDdpXuXN8ql57R5fUzhhDsbMgYFFLKAuBTCceiLmohgbQhNfdUXMQUy0fOIwlpkKiGktIGzkIK2TtcRbJ3bQseZZfJoW"
    "0FX4s0RQT4U/U/DTy8dsUdKqkOqO+bVxHWMjQLsKeLW4VtWIC9tREa8AHayjyV4Pah2zPwYXQBg9mesiRUPb/uKwY3gp9spNOomL"
    "1jOdJLNhjsjeK47I3hNR3LXSRY7aqn6oBDL1P1WieFrRC/UCeM1SqHialBpWV8FarAwn/aUIOCu7IhrSu0L1ye40TIFZ6ATMSnQ/"
    "3TQUPlZ2aWphUY8KBKyH5ZpCzhnCS1seikBgCNvqWGSEQsOpkB50cSaRdlJRrbKbkUZMt76nhkxzlMQZ29SCjAE5p+/+Wh7bB8F6"
    "mNkaC+6aL03HjHFgTtzOEID1DNt0IQe03czFEOujxQKCmy3dH5fUzfd9xcskbrTPdft6tbAdA1Je0a8yMZknip7iOQo1YkJ3LmVm"
    "pb7HEcynS4LgRyjuie5cXPz0HrD7w3tQtESw1kIAO0JDpiaAr2dPjX8klGmlUYU9vhEe0OgHXlcRAJHMUjEug/Hg7/1ra+COELg5"
    "8NinnzYgs98oBORP8pEqyVo5dMrFRGgpyxV12eWP143uic/sfdnv6zf0TgeQowrIF0Q7VjEIBDiquD1PelmU+IViGvED1CxQx0DX"
    "bza0Y1n+RJcD4HOfPlq0pqqy0YKI45hulaPIWF++AGZBLej02Cd5DSrVKd0XRLGxhoj54o7EBTzySpZkNLxJUqtQCIGjjNJ0tLa+"
    "9FprKkg1JI40S1QVX6TBBk+c82cKcJKaYqAClU+nwQPAFF8lb7cwsU53UGlpvov9aDhwUrErg0xMQRVS8BOueAIfPDY+wJKRbnoe"
    "B74eD5hPlNF2maqnM+XvxUJwepyWBAhOxb5zg/rGUebstRofnqpaV56hZk9fk+LLisZnt/kODTKR7Ej38QH2nEVYm9Q0lx8+pa+P"
    "0gJ50lklKYaJCODiCDCFWINxSwC6OrxsOSVOhQfQVp2WULB9tDyb663PR4pSRvZg2lVCuajbWA5q5QjXtzCN4TcAaU1SGQGfSZ6T"
    "0//qp3McL6dy/kwk+JKOg8/w9e35q0/nH8zFt6/sty7r77CmJxd/Y+igK2G0eJFfnb+O4TmVMXtV2zrL9UZe8RTwRbFFy0SXQB1V"
    "qttiaWQCVoBSphN9sThnfPPOQvZRfrB3lm67uDMfQBUMNtcENhfr7ws9jIZtORVqd0sgYyultW4dqWIyX/Vz7i4g9UG7EogFDlxC"
    "BGYtcsmQUQcjycxIubpwLxiCQfkQQ7wd353FfEoyKtwahZtHO6z7I4WTL66RSt2wZZS6U/B1CN7308XrS6uibWKWXwiLptAzdUkP"
    "4A+jKrowwmafTSgmJOTiGhctAvA1WcSQiUea7U1xK1YqGjH4PdhwXpn5C0gRUdQNbrzIgmyL1o+ZnDZYt0BNLIxC84Rr2+RALeSB"
    "ZfI9pbwEIIIdjoaermrF+QtXRNI+aiLIvzIv3RvPQCiTrh8ZtWxNGa20iIK8XLttcfUAdeqmXnF9VcX1oorryyoWvY4vMF1eMamx"
    "Zb2a/lvU1BlxF2MK+anxKVWRWTMaRs3eNUqwybGILFLCNr3COdoW9wHxIOOwl9mOaKdwSdj93NGc6I6qTLvrTV30lq12rYsPuFIO"
    "eMPVAg/jortUTZmArWp2P6ud492l+ScCaGGadnWDUGHtzyqAtkS65E4xKEGuIVkqhWNmGoK4zos53l2B7E0iQ/qWXaPg6C8dADwS"
    "Wm/ARYsEp0QtikijKQWfzNGM0sru/rYKSb6jQpILI633b97+ROGEkxviKTHRjOoqUdz8uH10GN8zOfC1e4aNtWGisezWP1ShoXd5"
    "ZwSx0wuDPWZwPSYCWbAs5xWARcX4RHp2ZADh4suoO5fjSfFhJLiJwy30Px5IHpU1+B74L8zBiDDJjGokdsRF94QccRm9uQSpZRrA"
    "TmsYj0c5CEmNTZktuQ5OybTPKAXmBiG0+D2fomCvgU1EHXy1aKJPLoI3qVDOA52QMU+ywHbxk5FYHUigol4+mydKGXnvKF8mg+4m"
    "l3Iz5QxhdE8XWAIi2v1//l/EAY6P8xb6OGBXBVrRyGVPgopQ6lxfSJUBKyNz1z6KgNoN1E33VUJhEI7pWhYOL8PXPxJ1hkoB+wi0"
    "CXdTXTdSYrh2u2TktUfkPIHrG0M2rEtZ2GkXRZ6cV0wl0RZoNHgP8OhxJxmHIRa7jYbL86DCEWOIC7FatNhtDx03tFPGkd5v2Qd1"
    "ZTr3yVAnAyO+xCS78lu4fPwcHM1doooUGMn1dYSU0i1bczcHDzJg+tmn8zfnpyfaJbc5AfY99DxARKwRiQ2IGFYmR+dSh0wTSQeI"
    "dGCXVygbdCmpy0d0iY6nYYz1W0sLLv7cx4UBWJ4AtzjB7yV0Kdgqr5txOnBh74cbQHH0NWDogc5iSBMYX/VphPCT6bFeCWtIkMkq"
    "pIRrJGd1cXnDrxNxOvqXTZOwSsFFVKeQBz9k5kl0mM/64qHwaV8MqOBxl/UvcVuhNwA5gne3o+YanRWCNhHh+NowOqcZpKOnF6gs"
    "KIy1SWji7NO7E1PxoJwqVFxmTncxWxBWjq+TO74mNKYlHGliiJYM1iRl5CLmS4V6RzbE6sP+ot5OjhL9I9Sp6duNy8B/jb3JXZNc"
    "hBo7HOyA3eKF+EepZfIQghT4ycftFbizN4zIvYwRcNKaH96ItpKV+As3zznvnbOL7N75WYE2neXyuTTt+hi5Fm8IAcRNgQjYa9Eg"
    "/ZkyfsSFhUUHDKwZahOdyH2lowXx+eNd5mOWE4pNLE/7K5ReNMnGmkYuWTXnJWvT0/LNJQk47BZr2lC8Q5l1GavbLeI7JSnhr4la"
    "/jKvk89r1BHbJdGo00tKo65yMIsRZ2FWQxq8f9CMoITIAJlBRSe4kdfkck+gGoNXAXWX7oXmj9kOcb4++J78pKU/sbcDuznErVPF"
    "uHoa0Tq3ECqbasc8cykEFYLnFX1PrqL+/lWmd5MWxO54AD/zPdWZLLOAJfM7ZvVPLj8Z32cyuFEw0QT4hMePulGOx7+UTP7I7goW"
    "X9jxkApUGPusMBu7Fhm7pRtpJ5U+dCcjoTz/Dwf7HP+fOma7fEPcRUyOECiT9h2ughtr8Nn3TwuOhNg29EO3JF3R+QCFGO2GsHdE"
    "9MYHrYG6fZvmCbyFZggUINYwHHYCbBd/0MFhpRYBpW3/icIaFh0BwtXmT0DU6KtlafreNo6/dG1j8gWGrdhi+sVoXpuXkFZacDXU"
    "8THmCKfj4ipFF5KCx8tdtVRe4bsub0In71HsVXH0yPB38voXunS81OUL2SM6fLWS+jp3vD90EPToLhd4EAVkV886lgquUD/G5bSb"
    "yqleS7cauYtshYydyo6MQD3cH7QBbm3AN82WQpLg4t4IvluHZuo/rKSBmDE90tpa2qwtt3O4+Oe/Ty4Qej/mWiQ3TZUI9vqEgruO"
    "keGU+euUcAzGObV1vLtEOM6IxmmBWHWKyd6tJ72OqhurBOXcwfjJeSl1xRezlOF0CIJ7r/ro+vl9FR5fkwHXOBiRIJcWEiOSp3Xe"
    "9JgUfYjzhJNAlhA8ugBYN1Qwk6bIazDXVsjvmTohAIDPAgUe98bEByGqMaTHHh1xEQvJnCeCGytpVh5AtpVII0kwd4BEFvN8ma0E"
    "E+2uS7pCUn6AWZDMKbF2qLYTjPlq8gHp4CFGlCAlekKWpeBWQDUYh43OEktiJ6Y7npXpZKXIdOGSbqnXFynCIvHV9Wxxchs4EZz/"
    "R6RK1gJdwnSBbjRRF2LzLtHuZBcb2sZVyLlcRfe48w4xPpnxwVFaExsFZb7ASEIqm+//gXW7EH/IE23LuHgbX3ukKbpvg+TG7lt4"
    "fkaVFljBG29GmybDUiBQVuqiT72xTzCkwxWOvFASuxc1F5H+4letTZlwlKXFQVCSn5a1yBuZr9lxaW/7SXN00lwZIZqHPIuMGAfQ"
    "e067zbcm8L0VBNKJSTXZG7Px6JGgmX2+e0swiSB+fU4SLJEfv6sJjxPkpIh3Ipn0JCol7xf0U9o1kR4D3CmGDLG0ExJYWTEOamVo"
    "9018rzrd6AEtLyCFzxjIiJZztCqSvotXWrmWglAr/pKsSiu7Kq3lq9JKViW2Fk5zBjw0/NKMrprhAsmCQg7kZj5Ruv3nnfn7X6Pu"
    "QzOfdaf4L3vK9aMar021YZzCekDcqU4DDbI8shROA2ncR5wMhYtT4qmejtByaQlV2cOltEwBS8V0CS7XKuw/gwrNtmmKZ6lm1Hhu"
    "rQfiOVCmCXg8yqBHJIGv2TQ/6Ydi12kbdn2IxZdmwQhhTPcTM4dQ0czi06gibZ2zFIo/wn+O6LPhqlPLkoZccaX4jiUJAY7qoRa+"
    "Vei6hPMLo9bAgYXN5shsFQHqNvT5gNm3KryOhNCsw226vfmUbtfw+HzNwEUysWwrMCRpwogcE7GHfk6OEoZ0I1bJkd6tIudtkpy2"
    "MX1Ln7YVkMYPUJPQXQY6dSTul64ByATvJ27YhqMhRezHaBB9f770rjZ2gmQm+gbu93DcR5j++N61AUC4MwX6K4W2iw0abgr2FzO5"
    "pTLhcne6pIduRqG7V2y22eBLWPhxIB7JAR+1V9A18PAiNy5kEbn5ZhaRWzyq3BhCnBt+krJuuq5F1s2Pcd1w+lPqQrbFtERJXOMi"
    "SvJ9LqKkeORcwgDTJqtL8a4sL7U34WYwf6g+uuNptEUh+5PvKe6OLjtI21x+++V5sX34fiwUjieTMGtEltiO6zd8zgJ1F5EyItd9"
    "Agstyg9bmj9fK60aIuMHozMTt9OyIU/sOKx7gZLBTlpLl3dmYeMHab+ufJQFCiI7zUXKnD1tDPjIi/uEpj65ay/eVAizPgecNirV"
    "HYQAu8FvHefcQ/zWdmPTaZC4aKndNFwkrUS613rSJ8aRT8zIixJKBnGcJTRoOpMJtTM7AqzcrxkvXjLdZH9m3BVVqdU3M8Eg2tYW"
    "hoZGRTyIyl7a3nrVlZPUnWJP0ryTKE40Ob5ENmo2ygxIN3qdjZstPyzSN2KlfUMN1rNJZzcJg8r1VnxILitVngtp1zeNEy0y4G4P"
    "nDlOkpQRLd3tYtpEhVXKlKRppr9xnpElIlOkEi4/pkqcnKvXNg7AY+iBGJcCHuArJAlOQW3rmryT0iMYoiMTOqM5koKnV2GfNE5K"
    "7SRdQEYo1aaQ4smg/QplsLhAbGZ8FxD1ie0i+VNqa0qVNb7cae5vdHaT2WgDP7PPznX/DUkh+TQAZYuEPlIZyYgLmttGM+2lFetq"
    "4TV/k8Gq8rJhCqpYGcFi2NrikIrNNR2dtDswmklgNc3jCObzTusequhSXCdfXvFU2dXjcRp6wUe/fRObuUED/hcgd1ihEAGSxQVI"
    "pMvdM6tXvuMfys+hEFU3tM7FN3DNyIUc1HTgUOdYjU5nMt6AQnPPLHHBqPQBoBzWscgnvIMa/EL6v8UiWStxG2xTdzxopoI1NBPV"
    "SzMl4zezbE1zyTrgJtqbU6CWCBf+jKixJ6l7bNIf5wVrroIOrtZZVuBxrOkqMUsKrwr/CW8Qey+GPNeu5aWvacsaA1gPtxgJd8nw"
    "86Na5gtWkqgwmZiKcQ+ahf3jZO2YHZ0wN0vBIelBoDEmV5xgS9BePiI+ZLtenEPeshSwzqgm3zQqF1rReEyeuuJOXJwkSFk8Mr1/"
    "gpphw5OS5+HehVHrG+c8Pc83DltEsN0+elS5wb1S7P0A5yLhYcRvAzLrPxY/DRPCpcmVqSVgRTcZFFDYv9Itj3sMBw5BFbTb0Qsv"
    "3ynqVyQu+iEDFZPj78PBdhWUNotiYUE0SofBcsP7UduIdx2uPJMoG1Mw12J3QCV/68JuretReBpzy534WyT+wM8LoWzbmGqPrsXG"
    "HQZ8Nzt38GkApyx4AeMYhWJ/GHCEpasrf7y8/AgPRSWZyvBjr2UDQeVP0GwCGZATWolCWwZAJL8SPQTezBCCciahGTv9sUtaU7rf"
    "OsIsagFBjUCC8abMJkLvqHwebrVCnMoempJHJJ6V4MQTFW+Z4hirGsg7TGCj5EkRoMEYl7dJvIfVyMy19nWeEJ/0ooeE2W3c/M1h"
    "l5tyXYqW5JqXhM9Zj4mVoxgbbZyg//TpnALRQI0LnAuTp+eojEysYBK3ctlS3ehkF6fDzmAhfrlvTG5EJJPn1EBy7ZMK5+t0dCqw"
    "SJaiIGQbyfZwLE4DagKiIAwlCv4TIUISdZc3DTza012WmwnpTBiJJioSKmAjHUg36ShfiyRIJmlXSplrk/TjsubatFKngDmypwHC"
    "4kmM4vLhaBE1FRySFi85AsAKJ5kKh4UJEYX1SjHznwWWeBqH5uWJixLsR1MYv2EyGafoCdrFYjifhlA5OMfZ2s9E0+ctr+/OcHDS"
    "MMPheBzh8KtF/FtDxYZdMGZbMRiIUzT+OJawRwIWIdYzLv/1a5xgmNbS8T5/np+BKEjmwK5AINZfw3Z2giILTDKdcKB7r72uOx3Q"
    "IuUnC0BLQ2Iramb6SCBfY5FaBYuk7m3nBWqpBaKgX04rbrPbTLeVp3nfcP07JrRlcbuvE3xlpYB1kb4Yt1cCKW63rPkzPPzOIxZV"
    "/p4Da7dKyQzOMJbFExoC5vGUKBVdeSBiuDmzhyZBlCNE1hMFRej72WrMoe90fWNL0PmtEGj8Ee7yFFNIgeGS+WMNlrxBMx1K7sEl"
    "fKZid6wHpuDFCraSFvVDIJN+llnSY380RRQ8EmZYjSGCfLygWWItm/p20xRfBF+FvWWyu+/ioSHRoV3wpSmvCM0PCsDgf4kDpdOt"
    "mXTuAbarFMCrN/hCAbRVCucpFkwWNu4/5sjp+u2rTZ0JEHxSE7AVnRO+wjqVKA13kJN8qien0T00iSS/LiwqDdmbvTYQsGaLjx/w"
    "S/4YR0/+E4EMrTs="
)


def embedded_dashboard():
    import zlib as _z
    return _z.decompress(base64.b64decode(DASHBOARD_B64))


# ----------------------------------------------------------------------------- backtest
def backtest(candles_by_sym, step=4):
    """Cammina nel passato con lo stesso motore tecnico (senza notizie/order book, non disponibili storicamente)."""
    trades = []
    for sym, c in candles_by_sym.items():
        i, free = 420 if len(c) > 520 else max(140, len(c) // 2), 0
        while i < len(c) - 2:
            if i >= free:
                t = technical(c[:i + 1])
                if t:
                    f = finalize(t)
                    if f["raw"]:
                        p, d = c[i][4], f["raw"]
                        horizon = TFINFO[f["tfm"]]["horizon"] // 900
                        lv = make_levels(p, d, f["sl_pct"])
                        risk = abs(p - lv["sl"])
                        res, r = "TIMEOUT", None
                        for j in range(i + 1, min(len(c), i + 1 + horizon)):
                            if d > 0:
                                if c[j][3] <= lv["sl"]: res, r = "SL", -1.0; break
                                if c[j][2] >= lv["tp1"]: res, r = "TP1", 1.5; break
                            else:
                                if c[j][2] >= lv["sl"]: res, r = "SL", -1.0; break
                                if c[j][3] <= lv["tp1"]: res, r = "TP1", 1.5; break
                            end = j
                        if r is None:
                            last = c[min(len(c) - 1, i + horizon)][4]
                            r = clamp(d * (last - p) / risk, -1, 1.5)
                        trades.append((sym, f["conf"], res, r, f["tfm"]))
                        free = i + horizon
            i += step
    return trades


def print_backtest(trades, demo=False):
    def row(name, lst):
        if not lst:
            print(f"  {name:<12} nessun trade")
            return
        w = sum(1 for t in lst if t[2] == "TP1")
        l = sum(1 for t in lst if t[2] == "SL")
        wr = f"{w / (w + l) * 100:5.1f}%" if w + l else "   n/d"
        print(f"  {name:<12} trade {len(lst):4d} | TP1 {w:4d} | SL {l:4d} | timeout {len(lst) - w - l:4d} | win rate {wr} | R medio {sum(t[3] for t in lst) / len(lst):+.2f}")
    print("\n=== BACKTEST (motore tecnico, R:R 1:1,5, orizzonte per time frame, senza commissioni) ===")
    if demo:
        print("  ATTENZIONE: dati SINTETICI con una tendenza inserita apposta. Questi numeri NON misurano nulla di reale.")
    row("TUTTI", trades)
    for lo, hi in ((60, 70), (70, 80), (80, 101)):
        row(f"conf {lo}-{min(hi, 100)}", [t for t in trades if lo <= t[1] < hi])
    for k in TFINFO:
        row(f"TF {TFINFO[k]['short']}", [t for t in trades if t[4] == k])
    print("  Win rate di pareggio con R:R 1:1,5 = 40% (prima di commissioni e slippage).")
    print("  Se 'R medio' è ≤ 0 il motore, sui dati provati, non ha vantaggio: non fidarti dei segnali.\n")


# ----------------------------------------------------------------------------- self test / netcheck
def selftest():
    ok = True

    def check(name, cond):
        nonlocal ok
        ok &= bool(cond)
        print(("OK   " if cond else "FAIL ") + name)
    up = [[i * 900, 100 + i, 101 + i, 99 + i, 100 + i, 10] for i in range(120)]
    S = calc(up)
    check("RSI = 100 su serie sempre crescente", S["rsi"][-1] > 99)
    check("EMA20 > EMA50 su trend rialzista", S["e20"][-1] > S["e50"][-1])
    dn = [[i * 900, 300 - i, 301 - i, 299 - i, 300 - i, 10] for i in range(120)]
    check("RSI < 1 su serie sempre decrescente", calc(dn)["rsi"][-1] < 1)
    check("aggregate 4x15m -> 1h", len(aggregate(up, 4)) == 30 and aggregate(up, 4)[0][5] == 40)
    t = technical([[i * 900, 100 + i * .5, 101 + i * .5, 99 + i * .5, 100 + i * .5, 10 + i % 3] for i in range(900)])
    check("score combinato positivo in trend rialzista", t and t["comb"] > 0)
    f = finalize(t)
    check("livelli: SL sotto entrata per LONG", make_levels(100, 1, .01)["sl"] < 100 < make_levels(100, 1, .01)["tp1"])
    check("evaluate rileva SL su LONG", evaluate(dict(dir=1, since=0, sl=99, tp1=102), [[900, 100, 100.5, 98.9, 99.5, 1]], 99.5) == "SL")
    check("evaluate rileva TP1 su SHORT", evaluate(dict(dir=-1, since=0, sl=101, tp1=98), [[900, 100, 100.2, 97.9, 98.2, 1]], 98.2) == "TP1")
    check("kw_sentiment positivo/negativo", kw_sentiment("Bitcoin surges to record high") > 0 > kw_sentiment("Exchange hack triggers crash"))
    print("\nTUTTI I TEST OK" if ok else "\nALCUNI TEST FALLITI")
    return ok


def netcheck():
    tests = [("Bitget candele", lambda: len(bitget_candles("BTCUSDT", 5))), ("Bitget ticker", lambda: len(bitget_tickers())),
             ("Bitget order book", lambda: round(bitget_imbalance("BTCUSDT"), 3)), ("Yahoo Finance", lambda: len(yahoo_candles("AAPL"))),
             ("Fear & Greed", fetch_fng), ("News cripto", lambda: len(fetch_crypto_news())), ("News Yahoo", lambda: len(fetch_yahoo_news("AAPL")))]
    for name, fn in tests:
        try:
            print(f"OK    {name}: {fn()}")
        except Exception as e:
            print(f"ERRORE {name}: {e}")
    print("AI Claude:", "chiave presente" if AI_KEY else "nessuna ANTHROPIC_API_KEY (verifica AI disattivata)", "| Telegram:", "configurato" if os.environ.get("TELEGRAM_TOKEN") else "non configurato")


def main():
    global SC
    ap = argparse.ArgumentParser(description="Super Scanner")
    ap.add_argument("--demo", action="store_true", help="dati simulati, tempo accelerato")
    ap.add_argument("--port", type=int, default=None, help="default 8000, oppure la variabile PORT (Render)")
    ap.add_argument("--host", default=None, help="default 127.0.0.1; 0.0.0.0 se c'è PORT (Render) o per aprire la dashboard da altri dispositivi")
    ap.add_argument("--interval", type=int, default=None, help="secondi tra i cicli (default 20, demo 2)")
    ap.add_argument("--no-ai", action="store_true")
    ap.add_argument("--backtest", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--netcheck", action="store_true")
    args = ap.parse_args()
    if args.interval is None:
        args.interval = 2 if args.demo else 20
    if args.port is None:
        args.port = int(os.environ.get("PORT", "8000"))
    if args.host is None:
        args.host = "0.0.0.0" if os.environ.get("PORT") else "127.0.0.1"
    if args.host == "0.0.0.0" and not os.environ.get("DASH_PASSWORD") and not args.demo:
        log("ATTENZIONE: la dashboard è pubblica e senza password. Imposta DASH_PASSWORD per proteggerla.")
    if args.selftest:
        sys.exit(0 if selftest() else 1)
    if args.netcheck:
        return netcheck()
    SC = Scanner(args)
    if args.backtest:
        log("Backtest: scarico lo storico..." if not args.demo else "Backtest su dati demo")
        if args.demo:
            SC.demo_init()
        else:
            SC.refresh_crypto(True)
            SC.refresh_yahoo()
        data = {s: a["candles"] for s, a in SC.assets.items() if len(a["candles"]) > 300}
        if not data:
            return log("Nessun dato scaricato: esegui --netcheck per capire quale fonte è bloccata.")
        return print_backtest(backtest(data), args.demo)
    log(f"Modalità {'DEMO' if args.demo else 'LIVE'} · AI {'attiva (' + AI_MODEL + ')' if SC.ai_enabled else 'non attiva (imposta ANTHROPIC_API_KEY)'} · "
        f"Telegram {'attivo' if SC.tg_token and SC.tg_chat else 'non configurato'}")
    threading.Thread(target=SC.loop, daemon=True).start()
    srv = ThreadingHTTPServer((args.host, args.port), Handler)
    log(f"Dashboard: http://{'127.0.0.1' if args.host in ('0.0.0.0', '') else args.host}:{args.port}  (Ctrl+C per uscire)")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        SC.save_state()


if __name__ == "__main__":
    main()
